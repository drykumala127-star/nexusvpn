package com.example

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusNavyDark
import com.example.ui.theme.NexusRoyalBlue
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.nexusvpn.admin.ui.AdminPortalScreen
import com.nexusvpn.core.auth.AuthManager
import com.nexusvpn.core.data.models.NexusUser
import com.nexusvpn.core.data.models.VpnServer
import com.nexusvpn.core.data.repository.NexusRepository
import com.nexusvpn.core.vpn.NexusVpnService
import com.nexusvpn.user.ui.account.AccountScreen
import com.nexusvpn.user.ui.browser.PrivateBrowserScreen
import com.nexusvpn.user.ui.home.HomeScreen
import com.nexusvpn.user.ui.server.ServerListScreen
import com.nexusvpn.user.ui.speedtest.SpeedTestScreen
import com.nexusvpn.user.ui.subscription.SubscriptionScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val authManager by lazy { AuthManager() }
    private val repository by lazy { NexusRepository() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        com.nexusvpn.core.appcheck.NexusAppCheck.initialize(this)

        setContent {
            MyApplicationTheme {
                NexusMainApp(
                    authManager = authManager,
                    repository = repository
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NexusMainApp(
    authManager: AuthManager,
    repository: NexusRepository
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isAdminMode by remember { mutableStateOf(false) }
    var currentTab by remember { mutableIntStateOf(0) } // 0: Home, 1: Servers, 2: SpeedTest, 3: Browser, 4: VIP, 5: Account

    // Otomatis Login sebagai Guest saat aplikasi pertama kali dibuka (Tanpa Form)
    LaunchedEffect(Unit) {
        if (!authManager.isUserLoggedIn) {
            authManager.signInAsGuest()
        }
    }

    val firebaseUser by authManager.observeAuthState().collectAsState(initial = authManager.currentUser)
    val userProfile by remember(firebaseUser?.uid) {
        val uid = firebaseUser?.uid
        if (uid.isNullOrBlank()) kotlinx.coroutines.flow.flowOf(null)
        else repository.observeUserProfile(uid)
    }.collectAsState(initial = null)
    val servers by repository.observeServers().collectAsState(initial = emptyList())

    val defaultServer = remember {
        VpnServer(
            id = "sg_01",
            name = "Singapore - SG01 (Fast)",
            countryCode = "SG",
            countryName = "Singapore",
            flagEmoji = "🇸🇬",
            host = "sg1.nexusvpn.net",
            port = 51820,
            serverPublicKey = "VpNEy4G7Wk18sSG01KjE98213uGhkLmsi91==",
            isPremium = false,
            isOnline = true,
            pingMs = 18,
            loadPercentage = 24
        )
    }

    var selectedServer by remember { mutableStateOf(defaultServer) }

    // Update selectedServer jika server list memuat server yang cocok
    LaunchedEffect(servers) {
        if (servers.isNotEmpty() && selectedServer == defaultServer) {
            selectedServer = servers.first()
        }
    }

    // Android VPN Permission Launcher (VpnService.prepare)
    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            NexusVpnService.startVpn(
                context = context,
                server = selectedServer
            )
        } else {
            Toast.makeText(context, "Izin VPN ditolak oleh pengguna", Toast.LENGTH_SHORT).show()
        }
    }

    fun requestConnectVpn() {
        // Cek izin VPN sistem Android
        val intent = VpnService.prepare(context)
        if (intent != null) {
            vpnPermissionLauncher.launch(intent)
        } else {
            // Sudah memiliki izin, langsung koneksikan
            NexusVpnService.startVpn(
                context = context,
                server = selectedServer
            )
        }
    }

    // BackHandler: Kembali ke Home jika sedang di tab lain atau Admin mode
    BackHandler(enabled = isAdminMode || currentTab != 0) {
        if (isAdminMode) {
            isAdminMode = false
        } else {
            currentTab = 0
        }
    }

    // View: Admin Portal
    if (isAdminMode) {
        AdminPortalScreen(
            repository = repository,
            onBackToUserApp = { isAdminMode = false }
        )
        return
    }

    // View: NEXUS VPN User App
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = NexusRoyalBlue,
                            modifier = Modifier.size(30.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.PowerSettingsNew,
                                    contentDescription = "Nexus",
                                    tint = NexusCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Text(
                            text = " NEXUS VPN",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = NexusNavyDark
                        )
                    }
                },
                actions = {
                    // Tombol cepat membuka Portal Admin
                    IconButton(
                        onClick = { isAdminMode = true }
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Switch to Admin Portal",
                            tint = NexusRoyalBlue
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp,
                windowInsets = WindowInsets(0, 0, 0, 0)
            ) {
                val navItems = listOf(
                    Triple("Home", Icons.Default.PowerSettingsNew, 0),
                    Triple("Servers", Icons.Default.Dns, 1),
                    Triple("Speed", Icons.Default.Speed, 2),
                    Triple("Browser", Icons.Default.Language, 3),
                    Triple("VIP", Icons.Default.Star, 4),
                    Triple("Account", Icons.Default.Person, 5)
                )

                navItems.forEach { (label, icon, tabIndex) ->
                    val isSelected = currentTab == tabIndex
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tabIndex },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (isSelected) NexusRoyalBlue else NexusTextSecondary
                            )
                        },
                        label = {
                            Text(
                                text = label,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) NexusRoyalBlue else NexusTextSecondary
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Color(0xFFE0EDFF)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                0 -> HomeScreen(
                    selectedServer = selectedServer,
                    onSelectServerClicked = { currentTab = 1 },
                    onRequestVpnPermission = { requestConnectVpn() }
                )
                1 -> ServerListScreen(
                    servers = servers,
                    selectedServer = selectedServer,
                    isUserPremium = userProfile?.isPremiumActive == true,
                    onSelectServer = { chosenServer ->
                        selectedServer = chosenServer
                        currentTab = 0
                        Toast.makeText(context, "Server dipilih: ${chosenServer.name}", Toast.LENGTH_SHORT).show()
                    },
                    onUpgradeRequired = {
                        currentTab = 4
                        Toast.makeText(context, "Server VIP! Silakan klaim trial atau aktifkan VIP", Toast.LENGTH_LONG).show()
                    }
                )
                2 -> SpeedTestScreen()
                3 -> PrivateBrowserScreen()
                4 -> SubscriptionScreen(
                    user = userProfile,
                    onClaimTrial = { callback ->
                        scope.launch {
                            // Simulasi klaim trial 24 jam via Auth UID
                            val uid = firebaseUser?.uid
                            if (uid != null) {
                                callback(true, "Selamat! Trial VIP 24 Jam Anda aktif sekarang!")
                            } else {
                                callback(false, "Silakan login terlebih dahulu.")
                            }
                        }
                    },
                    onPayWithQris = { plan ->
                        Toast.makeText(context, "Membuat invoice QRIS untuk ${plan.name}...", Toast.LENGTH_SHORT).show()
                    }
                )
                5 -> AccountScreen(
                    user = userProfile,
                    isGuest = authManager.isGuestUser,
                    onLoginWithEmail = { email, pass, cb ->
                        scope.launch {
                            val res = authManager.signInWithEmail(email, pass)
                            if (res.isSuccess) cb(true, "Login berhasil!")
                            else cb(false, res.exceptionOrNull()?.localizedMessage ?: "Login gagal")
                        }
                    },
                    onSignUpWithEmail = { email, pass, name, cb ->
                        scope.launch {
                            val res = authManager.signUpWithEmail(email, pass, name)
                            if (res.isSuccess) cb(true, "Registrasi berhasil!")
                            else cb(false, res.exceptionOrNull()?.localizedMessage ?: "Registrasi gagal")
                        }
                    },
                    onUpgradeGuest = { email, pass, cb ->
                        scope.launch {
                            val res = authManager.linkGuestWithEmail(email, pass)
                            if (res.isSuccess) cb(true, "Akun berhasil dihubungkan! UID Anda tetap terjaga.")
                            else cb(false, res.exceptionOrNull()?.localizedMessage ?: "Gagal menghubungkan akun")
                        }
                    },
                    onSignOut = {
                        authManager.signOut()
                        scope.launch { authManager.signInAsGuest() }
                    },
                    onOpenAdminPortal = {
                        isAdminMode = true
                    }
                )
            }
        }
    }
}
