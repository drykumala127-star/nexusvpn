package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Premium Brand Colors
val NexusRoyalBlue = Color(0xFF0052CC)
val NexusCyan = Color(0xFF00D2FF)
val NexusNavyDark = Color(0xFF0B1B3D)
val NexusLightBackground = Color(0xFFF8FAFC)
val NexusSurfaceWhite = Color(0xFFFFFFFF)
val NexusCardBorder = Color(0xFFE2E8F0)
val NexusTextPrimary = Color(0xFF0F172A)
val NexusTextSecondary = Color(0xFF64748B)

// Accent Status Colors
val NexusSuccessGreen = Color(0xFF10B981)
val NexusWarningAmber = Color(0xFFF59E0B)
val NexusErrorRed = Color(0xFFEF4444)
val NexusConnectedPill = Color(0xFFE6F4EA)
