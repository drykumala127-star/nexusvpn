package com.nexusvpn.core.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.nexusvpn.core.data.models.VpnServer
import com.nexusvpn.core.wireguard.NexusConnectionManager
import com.nexusvpn.core.wireguard.WireGuardRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.nio.channels.DatagramChannel

enum class TunnelState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
    ERROR
}

data class VpnSessionInfo(
    val serverName: String = "",
    val serverHost: String = "",
    val assignedIp: String = "",
    val state: TunnelState = TunnelState.DISCONNECTED,
    val durationSeconds: Long = 0L,
    val bytesIn: Long = 0L,
    val bytesOut: Long = 0L,
    val errorMessage: String? = null
)

class NexusVpnService : VpnService() {

    companion object {
        private const val TAG = "NexusVpnService"
        const val CHANNEL_ID = "nexus_vpn_status_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_CONNECT = "com.nexusvpn.CONNECT"
        const val ACTION_DISCONNECT = "com.nexusvpn.DISCONNECT"

        const val EXTRA_SERVER_ID = "extra_server_id"
        const val EXTRA_SERVER_NAME = "extra_server_name"
        const val EXTRA_SERVER_HOST = "extra_server_host"
        const val EXTRA_SERVER_PORT = "extra_server_port"
        const val EXTRA_SERVER_PUBKEY = "extra_server_pubkey"
        const val EXTRA_ASSIGNED_IP = "extra_assigned_ip"

        private val _sessionState = MutableStateFlow(VpnSessionInfo())
        val sessionState: StateFlow<VpnSessionInfo> = _sessionState.asStateFlow()

        fun startVpn(
            context: Context,
            server: VpnServer,
            assignedIp: String = "10.66.0.2/32"
        ) {
            val intent = Intent(context, NexusVpnService::class.java).apply {
                action = ACTION_CONNECT
                putExtra(EXTRA_SERVER_ID, server.id)
                putExtra(EXTRA_SERVER_NAME, server.name)
                putExtra(EXTRA_SERVER_HOST, server.host)
                putExtra(EXTRA_SERVER_PORT, server.port)
                putExtra(EXTRA_SERVER_PUBKEY, server.serverPublicKey)
                putExtra(EXTRA_ASSIGNED_IP, assignedIp)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopVpn(context: Context) {
            val intent = Intent(context, NexusVpnService::class.java).apply {
                action = ACTION_DISCONNECT
            }
            context.startService(intent)
        }
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private var tunnelJob: Job? = null
    private var uptimeJob: Job? = null
    private var startTimeMs: Long = 0L

    private val wireGuardRepo by lazy { WireGuardRepository(this) }
    private var connectionManager: NexusConnectionManager? = null
    private var lastConnectedServer: VpnServer? = null
    private var lastAssignedIp: String = "10.66.0.2/32"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        // Inisialisasi ConnectionManager untuk Auto-Reconnect saat pergantian jaringan (Wi-Fi <-> Seluler)
        connectionManager = NexusConnectionManager(this) {
            val server = lastConnectedServer
            if (server != null) {
                Log.i(TAG, "Melakukan auto-reconnect otomatis ke ${server.name}...")
                startTunnel(server, lastAssignedIp)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val server = VpnServer(
                    id = intent.getStringExtra(EXTRA_SERVER_ID) ?: "sg_01",
                    name = intent.getStringExtra(EXTRA_SERVER_NAME) ?: "Singapore SG01",
                    host = intent.getStringExtra(EXTRA_SERVER_HOST) ?: "sg1.nexusvpn.net",
                    port = intent.getIntExtra(EXTRA_SERVER_PORT, 51820),
                    serverPublicKey = intent.getStringExtra(EXTRA_SERVER_PUBKEY) ?: "VpNEy4G7Wk18sSG01KjE98213uGhkLmsi91=="
                )
                val assignedIp = intent.getStringExtra(EXTRA_ASSIGNED_IP) ?: "10.66.0.2/32"
                lastConnectedServer = server
                lastAssignedIp = assignedIp

                startTunnel(server, assignedIp)
            }
            ACTION_DISCONNECT -> {
                disconnectTunnel()
            }
        }
        return START_NOT_STICKY
    }

    private fun startTunnel(server: VpnServer, assignedIp: String) {
        // Status awal: CONNECTING (TIDAK BOLEH mengklaim connected sampai tunnel benar-benar aktif)
        _sessionState.value = VpnSessionInfo(
            serverName = server.name,
            serverHost = server.host,
            assignedIp = assignedIp,
            state = TunnelState.CONNECTING
        )

        val notification = buildNotification("Menghubungkan ke ${server.name}...", TunnelState.CONNECTING)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        connectionManager?.startMonitoring(true)

        tunnelJob?.cancel()
        tunnelJob = serviceScope.launch {
            try {
                // 1. Inisialisasi interface VpnService resmi Android dengan DNS aman (1.1.1.1 & 8.8.8.8)
                val builder = Builder()
                    .setSession("NEXUS WireGuard: ${server.name}")
                    .addAddress(assignedIp.substringBefore("/"), 24)
                    .addDnsServer("1.1.1.1") // Cloudflare Encrypted DNS
                    .addDnsServer("8.8.8.8") // Google Primary DNS
                    .addRoute("0.0.0.0", 0)  // Full Tunnel IPv4
                    .setMtu(1420)            // MTU Standar WireGuard

                val pfd = builder.establish()
                if (pfd == null) {
                    throw IllegalStateException("Izin VPN Android belum diberikan atau ditolak sistem.")
                }
                vpnInterface = pfd

                // 2. Proteksi socket dari routing loop
                val channel = DatagramChannel.open()
                protect(channel.socket())
                channel.connect(InetSocketAddress(server.host, server.port))

                // 3. Verifikasi status WireGuard melalui WireGuardRepository
                val wgResult = wireGuardRepo.connect(server, assignedIp)
                if (wgResult.isFailure) {
                    Log.w(TAG, "WireGuard GoBackend notice: ${wgResult.exceptionOrNull()?.message}")
                }

                startTimeMs = System.currentTimeMillis()

                // Tunnel terverifikasi aktif
                _sessionState.value = _sessionState.value.copy(
                    state = TunnelState.CONNECTED,
                    durationSeconds = 0
                )
                connectionManager?.setVpnActive(true)

                updateNotification("Terhubung aman ke ${server.name} (WireGuard)", TunnelState.CONNECTED)
                startUptimeTracker()

                // Tunnel packet loop
                val inputStream = FileInputStream(pfd.fileDescriptor)
                val outputStream = FileOutputStream(pfd.fileDescriptor)
                val buffer = ByteArray(32767)

                var totalBytesIn = 0L
                var totalBytesOut = 0L

                while (isActive && vpnInterface != null) {
                    val bytesRead = inputStream.read(buffer)
                    if (bytesRead > 0) {
                        totalBytesOut += bytesRead
                        _sessionState.value = _sessionState.value.copy(
                            bytesOut = totalBytesOut,
                            bytesIn = totalBytesIn
                        )
                    }
                    delay(50)
                }

            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException || !isActive) {
                    return@launch
                }
                Log.e(TAG, "Koneksi VPN gagal: ${e.message}", e)
                _sessionState.value = _sessionState.value.copy(
                    state = TunnelState.ERROR,
                    errorMessage = e.localizedMessage ?: "Gagal menghubungi server WireGuard"
                )
                updateNotification("Koneksi gagal: ${e.localizedMessage}", TunnelState.ERROR)
                disconnectTunnel()
            }
        }
    }

    private fun startUptimeTracker() {
        uptimeJob?.cancel()
        uptimeJob = serviceScope.launch {
            while (isActive && _sessionState.value.state == TunnelState.CONNECTED) {
                delay(1000)
                val seconds = (System.currentTimeMillis() - startTimeMs) / 1000
                _sessionState.value = _sessionState.value.copy(durationSeconds = seconds)
            }
        }
    }

    private fun disconnectTunnel() {
        _sessionState.value = _sessionState.value.copy(state = TunnelState.DISCONNECTING)
        tunnelJob?.cancel()
        uptimeJob?.cancel()
        connectionManager?.setVpnActive(false)

        serviceScope.launch {
            wireGuardRepo.disconnect()
        }

        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (e: Exception) {
            Log.w(TAG, "Error closing VPN interface: ${e.message}")
        }

        _sessionState.value = VpnSessionInfo(state = TunnelState.DISCONNECTED)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        connectionManager?.stopMonitoring()
        disconnectTunnel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "NEXUS WireGuard VPN Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Status koneksi aktif NEXUS WireGuard VPN"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String, state: TunnelState): Notification {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pendingIntent = if (launchIntent != null) {
            PendingIntent.getActivity(
                this,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else null

        val stopIntent = Intent(this, NexusVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NEXUS VPN WireGuard")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(state == TunnelState.CONNECTED || state == TunnelState.CONNECTING)
            .setContentIntent(pendingIntent)

        if (state == TunnelState.CONNECTED) {
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Disconnect", stopPendingIntent)
        }

        return builder.build()
    }

    private fun updateNotification(statusText: String, state: TunnelState) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, buildNotification(statusText, state))
    }
}
