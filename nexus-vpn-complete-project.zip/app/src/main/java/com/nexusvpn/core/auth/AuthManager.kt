package com.nexusvpn.core.auth

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class AuthManager(
    private val auth: FirebaseAuth = Firebase.auth,
    private val db: FirebaseFirestore = Firebase.firestore
) {
    companion object {
        private const val TAG = "NexusAuthManager"
    }

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    val isUserLoggedIn: Boolean
        get() = auth.currentUser != null

    val isGuestUser: Boolean
        get() = auth.currentUser?.isAnonymous == true

    // Stream status autentikasi real-time
    fun observeAuthState(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    // 1. Masuk sebagai Guest (Anonymous) langsung tanpa form registrasi
    suspend fun signInAsGuest(): Result<FirebaseUser> {
        return try {
            val result = auth.signInAnonymously().await()
            val user = result.user ?: throw IllegalStateException("User null setelah anonymous sign in")
            
            // Catat profile awal jika belum ada (non-blocking)
            try {
                val userRef = db.collection("users").document(user.uid)
                val doc = userRef.get().await()
                if (!doc.exists()) {
                    userRef.set(
                        mapOf(
                            "uid" to user.uid,
                            "email" to "",
                            "displayName" to "Guest User",
                            "role" to "user",
                            "isGuest" to true,
                            "isTrialUsed" to false,
                            "subscriptionPlan" to "free"
                        )
                    ).await()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Firestore user profile sync deferred: ${e.message}")
            }
            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "signInAsGuest auth failed", e)
            Result.failure(e)
        }
    }

    // 2. Login dengan Email & Password
    suspend fun signInWithEmail(email: String, pass: String): Result<FirebaseUser> {
        return try {
            val result = auth.signInWithEmailAndPassword(email.trim(), pass).await()
            val user = result.user ?: throw IllegalStateException("User null setelah email sign in")
            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "signInWithEmail failed", e)
            Result.failure(e)
        }
    }

    // 3. Registrasi akun baru dengan Email & Password
    suspend fun signUpWithEmail(email: String, pass: String, displayName: String): Result<FirebaseUser> {
        return try {
            val result = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
            val user = result.user ?: throw IllegalStateException("User null setelah registrasi")
            
            // Simpan profil di Firestore
            db.collection("users").document(user.uid).set(
                mapOf(
                    "uid" to user.uid,
                    "email" to email.trim(),
                    "displayName" to displayName.ifBlank { "Nexus Member" },
                    "role" to "user",
                    "isGuest" to false,
                    "isTrialUsed" to false,
                    "subscriptionPlan" to "free"
                )
            ).await()

            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "signUpWithEmail failed", e)
            Result.failure(e)
        }
    }

    // 4. Upgrade Akun Guest menjadi Akun Email/Password (LINKING TANPA KEHILANGAN UID)
    suspend fun linkGuestWithEmail(email: String, pass: String): Result<FirebaseUser> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("Tidak ada sesi login"))
        return try {
            val credential = EmailAuthProvider.getCredential(email.trim(), pass)
            val result = user.linkWithCredential(credential).await()
            val linkedUser = result.user ?: user

            // Update status isGuest menjadi false di Firestore sambil mempertahankan UID dan riwayat
            db.collection("users").document(linkedUser.uid).update(
                mapOf(
                    "email" to email.trim(),
                    "isGuest" to false
                )
            ).await()

            Log.i(TAG, "Guest successfully upgraded to permanent account with UID: ${linkedUser.uid}")
            Result.success(linkedUser)
        } catch (e: Exception) {
            Log.e(TAG, "linkGuestWithEmail failed", e)
            Result.failure(e)
        }
    }

    // 5. Upgrade Akun Guest menjadi Google Account (LINKING TANPA KEHILANGAN UID)
    suspend fun linkGuestWithCredential(credential: AuthCredential): Result<FirebaseUser> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("Tidak ada sesi login"))
        return try {
            val result = user.linkWithCredential(credential).await()
            val linkedUser = result.user ?: user

            db.collection("users").document(linkedUser.uid).update(
                mapOf(
                    "email" to (linkedUser.email ?: ""),
                    "displayName" to (linkedUser.displayName ?: "Google Member"),
                    "isGuest" to false
                )
            ).await()

            Result.success(linkedUser)
        } catch (e: Exception) {
            Log.e(TAG, "linkGuestWithCredential failed", e)
            Result.failure(e)
        }
    }

    // 6. Sign in dengan Google Credential
    suspend fun signInWithCredential(credential: AuthCredential): Result<FirebaseUser> {
        return try {
            val result = auth.signInWithCredential(credential).await()
            val user = result.user ?: throw IllegalStateException("User null setelah credential sign in")

            val userRef = db.collection("users").document(user.uid)
            val doc = userRef.get().await()
            if (!doc.exists()) {
                userRef.set(
                    mapOf(
                        "uid" to user.uid,
                        "email" to (user.email ?: ""),
                        "displayName" to (user.displayName ?: "Google Member"),
                        "role" to "user",
                        "isGuest" to false,
                        "isTrialUsed" to false,
                        "subscriptionPlan" to "free"
                    )
                ).await()
            }

            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "signInWithCredential failed", e)
            Result.failure(e)
        }
    }

    // 7. Periksa apakah user memiliki role Admin
    suspend fun checkIsAdmin(uid: String? = auth.currentUser?.uid): Boolean {
        if (uid.isNullOrBlank()) return false
        return try {
            val doc = db.collection("users").document(uid).get().await()
            doc.getString("role") == "admin"
        } catch (e: Exception) {
            Log.w(TAG, "checkIsAdmin query failed", e)
            false
        }
    }

    // 8. Sign Out
    fun signOut() {
        auth.signOut()
    }
}
