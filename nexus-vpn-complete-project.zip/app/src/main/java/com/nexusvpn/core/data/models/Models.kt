package com.nexusvpn.core.data.models

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class NexusUser(
    @DocumentId val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val role: String = "user", // "user" or "admin"
    val isGuest: Boolean = false,
    val isTrialUsed: Boolean = false,
    val trialExpiresAt: Timestamp? = null,
    val subscriptionPlan: String = "free", // "free" or "premium"
    val subscriptionExpiresAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val isPremiumActive: Boolean
        get() {
            if (subscriptionPlan != "premium") return false
            val expiry = subscriptionExpiresAt ?: return false
            return expiry.toDate().time > System.currentTimeMillis()
        }

    val isTrialActive: Boolean
        get() {
            val expiry = trialExpiresAt ?: return false
            return expiry.toDate().time > System.currentTimeMillis()
        }
}

@IgnoreExtraProperties
data class VpnServer(
    @DocumentId val id: String = "",
    val name: String = "",
    val countryCode: String = "",
    val countryName: String = "",
    val flagEmoji: String = "🌐",
    val host: String = "",
    val port: Int = 51820,
    val serverPublicKey: String = "",
    val isPremium: Boolean = false,
    val isOnline: Boolean = true,
    val pingMs: Int = 25,
    val loadPercentage: Int = 10,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class WireGuardPeerConfig(
    @DocumentId val peerId: String = "",
    val userId: String = "",
    val serverId: String = "",
    val clientPublicKey: String = "",
    val assignedIp: String = "10.66.0.2/32",
    val status: String = "active", // "active", "revoked", "expired"
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class QrisTransaction(
    @DocumentId val transactionId: String = "",
    val userId: String = "",
    val planType: String = "1_month",
    val amount: Long = 29000L,
    val status: String = "pending", // "pending", "paid", "expired", "failed"
    val qrisString: String = "",
    val merchantName: String = "NEXUS VPN Official",
    val referenceNumber: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    val paidAt: Timestamp? = null,
    val expiresAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Announcement(
    @DocumentId val id: String = "",
    val title: String = "",
    val content: String = "",
    val type: String = "info", // "info", "maintenance", "promo"
    val isActive: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AuditLog(
    @DocumentId val id: String = "",
    val adminUid: String = "",
    val adminEmail: String = "",
    val action: String = "",
    val target: String = "",
    val metadata: Map<String, Any> = emptyMap(),
    @ServerTimestamp val timestamp: Timestamp? = null
)
