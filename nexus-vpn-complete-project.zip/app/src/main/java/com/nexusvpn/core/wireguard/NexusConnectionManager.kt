package com.nexusvpn.core.wireguard

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class NetworkType {
    WIFI,
    CELLULAR,
    ETHERNET,
    NONE
}

data class NetworkStatus(
    val isConnected: Boolean = false,
    val networkType: NetworkType = NetworkType.NONE,
    val isMetered: Boolean = false
)

/**
 * Memantau kondisi jaringan fisik (Wi-Fi, Seluler) dan mengendalikan Auto-Reconnect WireGuard saat jaringan berganti.
 */
class NexusConnectionManager(
    private val context: Context,
    private val onAutoReconnectRequired: () -> Unit
) {
    companion object {
        private const val TAG = "NexusConnectionManager"
    }

    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val _networkStatus = MutableStateFlow(NetworkStatus())
    val networkStatus: StateFlow<NetworkStatus> = _networkStatus.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var isMonitoring = false
    private var wasVpnActiveBeforeLost = false

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            val capabilities = connectivityManager.getNetworkCapabilities(network)
            val type = when {
                capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> NetworkType.WIFI
                capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> NetworkType.CELLULAR
                capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> NetworkType.ETHERNET
                else -> NetworkType.NONE
            }

            val isMetered = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == false

            Log.i(TAG, "Jaringan aktif terdeteksi: $type (Metered: $isMetered)")
            _networkStatus.value = NetworkStatus(
                isConnected = true,
                networkType = type,
                isMetered = isMetered
            )

            // Jika jaringan sempat hilang saat VPN sedang aktif, picu Auto-Reconnect
            if (wasVpnActiveBeforeLost) {
                wasVpnActiveBeforeLost = false
                scope.launch {
                    delay(1200) // Tunggu socket routing stabil
                    Log.i(TAG, "Memicu auto-reconnect WireGuard setelah jaringan pulih...")
                    onAutoReconnectRequired()
                }
            }
        }

        override fun onLost(network: Network) {
            Log.w(TAG, "Koneksi jaringan fisik terputus.")
            _networkStatus.value = NetworkStatus(isConnected = false, networkType = NetworkType.NONE)
        }
    }

    fun startMonitoring(isVpnCurrentlyActive: Boolean) {
        if (isMonitoring) return
        try {
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            connectivityManager.registerNetworkCallback(request, networkCallback)
            isMonitoring = true
            wasVpnActiveBeforeLost = isVpnCurrentlyActive
            Log.i(TAG, "Network monitoring aktif.")
        } catch (e: Exception) {
            Log.e(TAG, "Gagal memulai network monitoring: ${e.message}")
        }
    }

    fun stopMonitoring() {
        if (!isMonitoring) return
        try {
            connectivityManager.unregisterNetworkCallback(networkCallback)
            isMonitoring = false
            Log.i(TAG, "Network monitoring dinonaktifkan.")
        } catch (e: Exception) {
            Log.w(TAG, "Gagal unregister network callback: ${e.message}")
        }
    }

    fun setVpnActive(active: Boolean) {
        wasVpnActiveBeforeLost = active
    }
}
