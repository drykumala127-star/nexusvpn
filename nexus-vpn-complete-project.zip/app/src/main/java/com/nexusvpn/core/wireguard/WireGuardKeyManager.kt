package com.nexusvpn.core.wireguard

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.wireguard.crypto.Key
import com.wireguard.crypto.KeyPair

/**
 * Mengelola pembuatan dan penyimpanan Curve25519 KeyPair WireGuard di perangkat pengguna.
 * PENTING: Private key disimpan HANYA di penyimpanan lokal perangkat, TIDAK PERNAH dikirim ke server/backend!
 */
class WireGuardKeyManager(context: Context) {

    companion object {
        private const val TAG = "WireGuardKeyManager"
        private const val PREFS_NAME = "nexus_wireguard_keys"
        private const val KEY_PRIVATE_KEY = "wg_private_key"
        private const val KEY_PUBLIC_KEY = "wg_public_key"
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /**
     * Mengambil keypair yang sudah ada atau membuat keypair baru jika belum ada.
     */
    fun getOrCreateKeyPair(): KeyPair {
        val savedPrivateKey = prefs.getString(KEY_PRIVATE_KEY, null)
        if (savedPrivateKey != null) {
            try {
                val privateKey = Key.fromBase64(savedPrivateKey)
                return KeyPair(privateKey)
            } catch (e: Exception) {
                Log.w(TAG, "Gagal memuat private key yang tersimpan, membuat keypair baru: ${e.message}")
            }
        }

        // Buat Curve25519 KeyPair resmi baru
        val newKeyPair = KeyPair()
        prefs.edit()
            .putString(KEY_PRIVATE_KEY, newKeyPair.privateKey.toBase64())
            .putString(KEY_PUBLIC_KEY, newKeyPair.publicKey.toBase64())
            .apply()

        Log.i(TAG, "KeyPair WireGuard baru berhasil dibuat di perangkat lokal.")
        return newKeyPair
    }

    /**
     * Mengambil public key dalam format Base64 untuk dikirimkan ke backend.
     */
    fun getPublicKeyBase64(): String {
        return getOrCreateKeyPair().publicKey.toBase64()
    }

    /**
     * Mengambil private key dalam format Base64 (Hanya untuk konfigurasi interface tunnel lokal).
     */
    fun getPrivateKeyBase64(): String {
        return getOrCreateKeyPair().privateKey.toBase64()
    }

    /**
     * Menghapus kunci lama (misal saat logout / reset identitas).
     */
    fun clearKeys() {
        prefs.edit().clear().apply()
        Log.i(TAG, "Kunci lokal WireGuard telah dibersihkan.")
    }
}
