package com.nexusvpn.core.data.repository

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.firestore
import com.google.firebase.firestore.snapshots
import com.nexusvpn.core.data.models.Announcement
import com.nexusvpn.core.data.models.AuditLog
import com.nexusvpn.core.data.models.NexusUser
import com.nexusvpn.core.data.models.QrisTransaction
import com.nexusvpn.core.data.models.VpnServer
import com.nexusvpn.core.data.models.WireGuardPeerConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class NexusRepository(
    private val db: FirebaseFirestore = Firebase.firestore
) {
    companion object {
        private const val TAG = "NexusRepository"

        val defaultFallbackServers = listOf(
            VpnServer(
                id = "sg_01",
                name = "Singapore - SG01 (Fast)",
                countryCode = "SG",
                countryName = "Singapore",
                flagEmoji = "🇸🇬",
                host = "sg1.nexusvpn.net",
                port = 51820,
                serverPublicKey = "VpNEy4G7Wk18sSG01KjE98213uGhkLmsi91==",
                isPremium = false,
                isOnline = true,
                pingMs = 18,
                loadPercentage = 24
            ),
            VpnServer(
                id = "id_01",
                name = "Indonesia - Jakarta JKT01",
                countryCode = "ID",
                countryName = "Indonesia",
                flagEmoji = "🇮🇩",
                host = "id1.nexusvpn.net",
                port = 51820,
                serverPublicKey = "ID897hKgYt1892JKT01LmNpQRsTuVwXyZ==",
                isPremium = false,
                isOnline = true,
                pingMs = 22,
                loadPercentage = 38
            ),
            VpnServer(
                id = "jp_vip",
                name = "Tokyo - Tokyo Ultra VIP",
                countryCode = "JP",
                countryName = "Japan",
                flagEmoji = "🇯🇵",
                host = "jp1.nexusvpn.net",
                port = 51820,
                serverPublicKey = "JPtokyo991024VIPWGKeyPub8812739==",
                isPremium = true,
                isOnline = true,
                pingMs = 54,
                loadPercentage = 15
            ),
            VpnServer(
                id = "us_vip",
                name = "US West - Los Angeles VIP",
                countryCode = "US",
                countryName = "United States",
                flagEmoji = "🇺🇸",
                host = "us1.nexusvpn.net",
                port = 51820,
                serverPublicKey = "USla98810237VIPWGKeyPubLaWest==",
                isPremium = true,
                isOnline = true,
                pingMs = 145,
                loadPercentage = 18
            )
        )
    }

    // 1. Observe Server Fleet with resilient fallback
    fun observeServers(): Flow<List<VpnServer>> {
        return try {
            db.collection("servers")
                .whereEqualTo("isOnline", true)
                .snapshots()
                .map { snapshot ->
                    val list = snapshot.toObjects(VpnServer::class.java).sortedBy { it.pingMs }
                    if (list.isEmpty()) defaultFallbackServers else list
                }
                .catch { e ->
                    Log.w(TAG, "observeServers falling back to bundled servers: ${e.message}")
                    emit(defaultFallbackServers)
                }
        } catch (e: Exception) {
            Log.w(TAG, "observeServers init falling back: ${e.message}")
            flowOf(defaultFallbackServers)
        }
    }

    // 2. Observe User Profile with resilient fallback
    fun observeUserProfile(uid: String): Flow<NexusUser?> {
        if (uid.isBlank()) return flowOf(null)
        val defaultGuestProfile = NexusUser(uid = uid, displayName = "Nexus Guest", isGuest = true)
        return try {
            db.collection("users").document(uid)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) snapshot.toObject(NexusUser::class.java) ?: defaultGuestProfile
                    else defaultGuestProfile
                }
                .catch { e ->
                    Log.w(TAG, "observeUserProfile falling back: ${e.message}")
                    emit(defaultGuestProfile)
                }
        } catch (e: Exception) {
            Log.w(TAG, "observeUserProfile init error: ${e.message}")
            flowOf(defaultGuestProfile)
        }
    }

    // 3. Observe Announcements
    fun observeAnnouncements(): Flow<List<Announcement>> {
        return try {
            db.collection("announcements")
                .whereEqualTo("isActive", true)
                .snapshots()
                .map { snapshot -> snapshot.toObjects(Announcement::class.java) }
                .catch { e ->
                    Log.w(TAG, "observeAnnouncements error", e)
                    emit(emptyList())
                }
        } catch (e: Exception) {
            Log.w(TAG, "observeAnnouncements init error", e)
            flowOf(emptyList())
        }
    }

    // 4. Observe User Transactions (QRIS)
    fun observeUserTransactions(uid: String): Flow<List<QrisTransaction>> {
        if (uid.isBlank()) return flowOf(emptyList())
        return try {
            db.collection("qris_transactions")
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(QrisTransaction::class.java).sortedByDescending { it.createdAt?.toDate() }
                }
                .catch { e ->
                    Log.w(TAG, "observeUserTransactions error", e)
                    emit(emptyList())
                }
        } catch (e: Exception) {
            Log.w(TAG, "observeUserTransactions init error", e)
            flowOf(emptyList())
        }
    }

    // --- ADMIN METHODS ---

    fun observeAllUsers(): Flow<List<NexusUser>> {
        return try {
            db.collection("users")
                .snapshots()
                .map { snapshot -> snapshot.toObjects(NexusUser::class.java) }
                .catch { e ->
                    Log.w(TAG, "observeAllUsers error: ${e.message}")
                    emit(emptyList())
                }
        } catch (e: Exception) {
            flowOf(emptyList())
        }
    }

    fun observeAllTransactions(): Flow<List<QrisTransaction>> {
        return try {
            db.collection("qris_transactions")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(QrisTransaction::class.java).sortedByDescending { it.createdAt?.toDate() }
                }
                .catch { e ->
                    Log.w(TAG, "observeAllTransactions error: ${e.message}")
                    emit(emptyList())
                }
        } catch (e: Exception) {
            flowOf(emptyList())
        }
    }

    fun observeAllPeers(): Flow<List<WireGuardPeerConfig>> {
        return try {
            db.collection("wireguard_peers")
                .snapshots()
                .map { snapshot -> snapshot.toObjects(WireGuardPeerConfig::class.java) }
                .catch { e ->
                    Log.w(TAG, "observeAllPeers error: ${e.message}")
                    emit(emptyList())
                }
        } catch (e: Exception) {
            flowOf(emptyList())
        }
    }

    fun observeAuditLogs(): Flow<List<AuditLog>> {
        return try {
            db.collection("audit_logs")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(100)
                .snapshots()
                .map { snapshot -> snapshot.toObjects(AuditLog::class.java) }
                .catch { e ->
                    Log.w(TAG, "observeAuditLogs error: ${e.message}")
                    emit(emptyList())
                }
        } catch (e: Exception) {
            flowOf(emptyList())
        }
    }

    suspend fun addServer(server: VpnServer): Result<Unit> {
        return try {
            val docRef = if (server.id.isNotBlank()) {
                db.collection("servers").document(server.id)
            } else {
                db.collection("servers").document()
            }
            docRef.set(server.copy(id = docRef.id)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "addServer error", e)
            Result.failure(e)
        }
    }

    suspend fun deleteServer(serverId: String): Result<Unit> {
        return try {
            db.collection("servers").document(serverId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "deleteServer error", e)
            Result.failure(e)
        }
    }

    suspend fun logAuditAction(adminUid: String, adminEmail: String, action: String, target: String, metadata: Map<String, Any> = emptyMap()) {
        try {
            val logRef = db.collection("audit_logs").document()
            logRef.set(
                AuditLog(
                    id = logRef.id,
                    adminUid = adminUid,
                    adminEmail = adminEmail,
                    action = action,
                    target = target,
                    metadata = metadata,
                    timestamp = Timestamp.now()
                )
            ).await()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to write audit log: ${e.message}")
        }
    }
}
