package com.nexusvpn.core.wireguard

import android.content.Context
import android.util.Log
import com.nexusvpn.core.data.models.VpnServer
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.InetEndpoint
import com.wireguard.config.InetNetwork
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import com.wireguard.crypto.Key
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.net.InetAddress

class NexusTunnel(private val name: String) : Tunnel {
    override fun getName(): String = name
    override fun onStateChange(newState: Tunnel.State) {
        Log.i("NexusTunnel", "WireGuard Tunnel $name state changed to: $newState")
    }
}

/**
 * Repository resmi untuk konfigurasi, inisialisasi, dan pemeriksaan status WireGuard Tunnel asli.
 */
class WireGuardRepository(private val context: Context) {

    companion object {
        private const val TAG = "WireGuardRepository"
        const val TUNNEL_NAME = "nexus_wg0"
    }

    private val keyManager = WireGuardKeyManager(context)
    private var backend: Backend? = null
    private val tunnel = NexusTunnel(TUNNEL_NAME)

    private val _tunnelState = MutableStateFlow(Tunnel.State.DOWN)
    val tunnelState: StateFlow<Tunnel.State> = _tunnelState.asStateFlow()

    init {
        try {
            backend = GoBackend(context.applicationContext)
            Log.i(TAG, "WireGuard GoBackend resmi berhasil diinisialisasi.")
        } catch (t: Throwable) {
            Log.w(TAG, "Inisialisasi GoBackend ditunda/fallback: ${t.message}")
        }
    }

    /**
     * Membangun Config WireGuard resmi dengan DNS aman (1.1.1.1, 8.8.8.8) dan private key lokal.
     */
    fun buildWireGuardConfig(
        server: VpnServer,
        assignedIp: String = "10.66.0.2/32"
    ): Config {
        val clientPrivateKey = keyManager.getOrCreateKeyPair().privateKey
        val serverPublicKey = Key.fromBase64(server.serverPublicKey)

        // 1. Interface Lokal
        val interfaceBuilder = Interface.Builder()
            .parsePrivateKey(clientPrivateKey.toBase64())
            .addAddress(InetNetwork.parse(assignedIp))
            .addDnsServer(InetAddress.getByName("1.1.1.1"))
            .addDnsServer(InetAddress.getByName("8.8.8.8"))

        // 2. Peer Server Remotely
        val peerBuilder = Peer.Builder()
            .parsePublicKey(serverPublicKey.toBase64())
            .setEndpoint(InetEndpoint.parse("${server.host}:${server.port}"))
            .parseAllowedIPs("0.0.0.0/0, ::/0") // Full Tunnel Routing
            .setPersistentKeepalive(25) // Menjaga tunnel tetap hidup melewati NAT

        return Config.Builder()
            .setInterface(interfaceBuilder.build())
            .addPeer(peerBuilder.build())
            .build()
    }

    /**
     * Menghubungkan tunnel WireGuard sesungguhnya dan memverifikasi status UP.
     */
    suspend fun connect(server: VpnServer, assignedIp: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val config = buildWireGuardConfig(server, assignedIp)
            val currentBackend = backend ?: GoBackend(context.applicationContext).also { backend = it }

            Log.i(TAG, "Mengaktifkan WireGuard Tunnel ke ${server.name} (${server.host})...")
            val targetState = currentBackend.setState(tunnel, Tunnel.State.UP, config)

            if (targetState == Tunnel.State.UP) {
                _tunnelState.value = Tunnel.State.UP
                Log.i(TAG, "WireGuard Tunnel TERVERIFIKASI BERHASIL AKTIF (State: UP).")
                Result.success(Unit)
            } else {
                _tunnelState.value = Tunnel.State.DOWN
                Result.failure(IllegalStateException("Tunnel gagal mencapai status UP. Status saat ini: $targetState"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gagal mengaktifkan WireGuard tunnel: ${e.message}", e)
            _tunnelState.value = Tunnel.State.DOWN
            Result.failure(e)
        }
    }

    /**
     * Memutuskan tunnel WireGuard secara bersih.
     */
    suspend fun disconnect(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            backend?.setState(tunnel, Tunnel.State.DOWN, null)
            _tunnelState.value = Tunnel.State.DOWN
            Log.i(TAG, "WireGuard Tunnel berhasil dimatikan (State: DOWN).")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Gagal mematikan WireGuard tunnel: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun getClientPublicKeyBase64(): String {
        return keyManager.getPublicKeyBase64()
    }
}
