package com.nexusvpn.core.appcheck

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory

object NexusAppCheck {
    private const val TAG = "NexusAppCheck"

    fun initialize(context: Context) {
        try {
            val appCheck = FirebaseAppCheck.getInstance()
            // Menggunakan DebugAppCheckProviderFactory agar aplikasi tidak terblokir di emulator
            appCheck.installAppCheckProviderFactory(
                DebugAppCheckProviderFactory.getInstance()
            )
            Log.i(TAG, "Firebase App Check initialized safely in debug mode")
        } catch (t: Throwable) {
            Log.w(TAG, "App Check skipped: ${t.message}")
        }
    }
}
