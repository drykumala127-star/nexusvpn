package com.nexusvpn.user.ui.server

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NexusCardBorder
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusLightBackground
import com.example.ui.theme.NexusNavyDark
import com.example.ui.theme.NexusRoyalBlue
import com.example.ui.theme.NexusSuccessGreen
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusWarningAmber
import com.nexusvpn.core.data.models.VpnServer

@Composable
fun ServerListScreen(
    servers: List<VpnServer>,
    selectedServer: VpnServer,
    isUserPremium: Boolean,
    onSelectServer: (VpnServer) -> Unit,
    onUpgradeRequired: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }

    val defaultFallbackServers = remember {
        listOf(
            VpnServer(
                id = "sg_01",
                name = "Singapore - SG01 (Fast)",
                countryCode = "SG",
                countryName = "Singapore",
                flagEmoji = "🇸🇬",
                host = "sg1.nexusvpn.net",
                port = 51820,
                serverPublicKey = "VpNEy4G7Wk18sSG01KjE98213uGhkLmsi91==",
                isPremium = false,
                isOnline = true,
                pingMs = 18,
                loadPercentage = 24
            ),
            VpnServer(
                id = "id_01",
                name = "Indonesia - Jakarta JKT01",
                countryCode = "ID",
                countryName = "Indonesia",
                flagEmoji = "🇮🇩",
                host = "id1.nexusvpn.net",
                port = 51820,
                serverPublicKey = "ID897hKgYt1892JKT01LmNpQRsTuVwXyZ==",
                isPremium = false,
                isOnline = true,
                pingMs = 22,
                loadPercentage = 38
            ),
            VpnServer(
                id = "jp_vip",
                name = "Tokyo - Tokyo Ultra VIP",
                countryCode = "JP",
                countryName = "Japan",
                flagEmoji = "🇯🇵",
                host = "jp1.nexusvpn.net",
                port = 51820,
                serverPublicKey = "JPtokyo991024VIPWGKeyPub8812739==",
                isPremium = true,
                isOnline = true,
                pingMs = 54,
                loadPercentage = 15
            ),
            VpnServer(
                id = "us_vip",
                name = "US West - Los Angeles VIP",
                countryCode = "US",
                countryName = "United States",
                flagEmoji = "🇺🇸",
                host = "us1.nexusvpn.net",
                port = 51820,
                serverPublicKey = "USla98810237VIPWGKeyPubLaWest==",
                isPremium = true,
                isOnline = true,
                pingMs = 145,
                loadPercentage = 18
            )
        )
    }

    val activeList = if (servers.isNotEmpty()) servers else defaultFallbackServers

    val filteredList = activeList.filter { server ->
        val matchesSearch = server.name.contains(searchQuery, ignoreCase = true) ||
                server.countryName.contains(searchQuery, ignoreCase = true)
        val matchesTab = when (selectedTab) {
            1 -> !server.isPremium // Free only
            2 -> server.isPremium  // VIP only
            else -> true          // All
        }
        matchesSearch && matchesTab
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusLightBackground)
            .padding(16.dp)
    ) {
        Text(
            text = "VPN Locations",
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            color = NexusNavyDark
        )
        Text(
            text = "Select high-speed encrypted WireGuard nodes",
            fontSize = 13.sp,
            color = NexusTextSecondary,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // 1. Auto-Select Best Server Pill
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE0EDFF)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBAE6FD)),
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    val fastest = activeList
                        .filter { if (!isUserPremium) !it.isPremium else true }
                        .minByOrNull { it.pingMs }
                    if (fastest != null) {
                        onSelectServer(fastest)
                    }
                }
                .testTag("auto_select_server_button")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(NexusRoyalBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlashOn,
                            contentDescription = "Auto Fastest",
                            tint = NexusCyan,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Auto-Select (Fastest Ping)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = NexusNavyDark
                        )
                        Text(
                            text = "Optimal low-latency server based on your ISP",
                            fontSize = 11.sp,
                            color = NexusTextSecondary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = NexusRoyalBlue
                ) {
                    Text(
                        text = "Auto",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 2. Search Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search country, city, or protocol...") },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = "Search", tint = NexusTextSecondary)
            },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 3. Category Tabs (All, Free, VIP)
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            divider = {},
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            listOf("All (${activeList.size})", "Free", "VIP Premium").forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) NexusRoyalBlue else NexusTextSecondary
                        )
                    }
                )
            }
        }

        // 4. Server Cards List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredList) { server ->
                val isSelected = selectedServer.id == server.id
                val canAccess = !server.isPremium || isUserPremium

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFFF0F9FF) else Color.White
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) NexusCyan else NexusCardBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (canAccess) {
                                onSelectServer(server)
                            } else {
                                onUpgradeRequired()
                            }
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = server.flagEmoji.ifBlank { "🌐" },
                                fontSize = 28.sp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = server.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = NexusTextPrimary
                                    )
                                    if (server.isPremium) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color(0xFFFEF3C7)
                                        ) {
                                            Text(
                                                text = "VIP",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFD97706),
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(top = 2.dp)
                                ) {
                                    // Ping dot
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when {
                                                    server.pingMs < 40 -> NexusSuccessGreen
                                                    server.pingMs < 100 -> NexusWarningAmber
                                                    else -> Color(0xFFEF4444)
                                                }
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${server.pingMs} ms • Load: ${server.loadPercentage}%",
                                        fontSize = 12.sp,
                                        color = NexusTextSecondary
                                    )
                                }
                            }
                        }

                        // Right side Action/Indicator
                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(NexusCyan),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Selected",
                                    tint = NexusNavyDark,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        } else if (server.isPremium && !isUserPremium) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "VIP Locked",
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
