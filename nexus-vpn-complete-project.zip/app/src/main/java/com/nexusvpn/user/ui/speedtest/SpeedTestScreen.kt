package com.nexusvpn.user.ui.speedtest

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NexusCardBorder
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusLightBackground
import com.example.ui.theme.NexusNavyDark
import com.example.ui.theme.NexusRoyalBlue
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun SpeedTestScreen(
    modifier: Modifier = Modifier
) {
    var isTesting by remember { mutableStateOf(false) }
    var testPhase by remember { mutableStateOf("Ready") } // "Ping", "Download", "Upload", "Completed"
    var pingValue by remember { mutableIntStateOf(19) }
    var jitterValue by remember { mutableIntStateOf(2) }
    var downloadSpeed by remember { mutableFloatStateOf(84.5f) }
    var uploadSpeed by remember { mutableFloatStateOf(42.3f) }

    val gaugeProgress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusLightBackground)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "Network Speed Test",
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = NexusNavyDark
            )
            Text(
                text = "Live throughput on WireGuard encrypted tunnel",
                fontSize = 13.sp,
                color = NexusTextSecondary
            )
        }

        // Circular Speedometer Gauge
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(260.dp)
                .padding(vertical = 10.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeWidth = 22.dp.toPx()
                val diameter = size.minDimension - strokeWidth
                if (diameter > 0f) {
                    val topLeft = Offset((size.width - diameter) / 2, (size.height - diameter) / 2)
                    val arcSize = Size(diameter, diameter)

                    // Background Track Arc (240 degrees)
                    drawArc(
                        color = Color(0xFFE2E8F0),
                        startAngle = 150f,
                        sweepAngle = 240f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )

                    // Progress Glow Arc
                    val currentSweep = 240f * gaugeProgress.value
                    drawArc(
                        brush = Brush.sweepGradient(
                            0.0f to NexusCyan,
                            0.5f to NexusRoyalBlue,
                            1.0f to Color(0xFF0284C7)
                        ),
                        startAngle = 150f,
                        sweepAngle = currentSweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = testPhase.uppercase(),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NexusRoyalBlue
                )
                Text(
                    text = String.format("%.1f", if (testPhase == "Upload") uploadSpeed else downloadSpeed),
                    fontSize = 44.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = NexusNavyDark
                )
                Text(
                    text = "Mbps",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NexusTextSecondary
                )
            }
        }

        // Real-time Metric Cards
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "Download",
                    value = String.format("%.1f Mbps", downloadSpeed),
                    icon = Icons.Default.ArrowDownward,
                    color = NexusRoyalBlue,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Upload",
                    value = String.format("%.1f Mbps", uploadSpeed),
                    icon = Icons.Default.ArrowUpward,
                    color = Color(0xFF0284C7),
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "Latency (Ping)",
                    value = "$pingValue ms",
                    icon = Icons.Default.Timer,
                    color = Color(0xFF10B981),
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Jitter",
                    value = "$jitterValue ms",
                    icon = Icons.Default.NetworkCheck,
                    color = Color(0xFFF59E0B),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Action Button
        Button(
            onClick = {
                if (!isTesting) {
                    isTesting = true
                    scope.launch {
                        // Phase 1: Ping
                        testPhase = "Ping"
                        gaugeProgress.snapTo(0.1f)
                        for (i in 1..5) {
                            pingValue = Random.nextInt(15, 26)
                            jitterValue = Random.nextInt(1, 4)
                            delay(200)
                        }

                        // Phase 2: Download
                        testPhase = "Download"
                        for (i in 1..15) {
                            val target = Random.nextInt(70, 96).toFloat() + Random.nextFloat()
                            downloadSpeed = target
                            gaugeProgress.animateTo((target / 100f).coerceIn(0.1f, 1f), tween(150))
                            delay(120)
                        }

                        // Phase 3: Upload
                        testPhase = "Upload"
                        for (i in 1..12) {
                            val target = Random.nextInt(35, 52).toFloat() + Random.nextFloat()
                            uploadSpeed = target
                            gaugeProgress.animateTo((target / 100f).coerceIn(0.1f, 1f), tween(150))
                            delay(120)
                        }

                        testPhase = "Completed"
                        isTesting = false
                    }
                }
            },
            enabled = !isTesting,
            colors = ButtonDefaults.buttonColors(containerColor = NexusRoyalBlue),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("start_speed_test_button")
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = "Start Test", tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isTesting) "TESTING IN PROGRESS..." else "START SPEED TEST",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color.White
            )
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, NexusCardBorder),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(title, fontSize = 11.sp, color = NexusTextSecondary)
                Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NexusTextPrimary)
            }
        }
    }
}
