package com.nexusvpn.user.ui.home

import android.content.Context
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NexusCardBorder
import com.example.ui.theme.NexusConnectedPill
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusErrorRed
import com.example.ui.theme.NexusLightBackground
import com.example.ui.theme.NexusNavyDark
import com.example.ui.theme.NexusRoyalBlue
import com.example.ui.theme.NexusSuccessGreen
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.nexusvpn.core.data.models.VpnServer
import com.nexusvpn.core.vpn.NexusVpnService
import com.nexusvpn.core.vpn.TunnelState
import com.nexusvpn.core.vpn.VpnSessionInfo

@Composable
fun HomeScreen(
    selectedServer: VpnServer,
    onSelectServerClicked: () -> Unit,
    onRequestVpnPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val vpnSession by NexusVpnService.sessionState.collectAsState()

    val isConnected = vpnSession.state == TunnelState.CONNECTED
    val isConnecting = vpnSession.state == TunnelState.CONNECTING

    val infiniteTransition = rememberInfiniteTransition(label = "pulse_transition")
    val animatedPulse by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isConnecting) 1.25f else 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )
    val pulseScale = if (isConnected || isConnecting) animatedPulse else 1f

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusLightBackground)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 1. Header & Status Pill
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = when (vpnSession.state) {
                    TunnelState.CONNECTED -> NexusConnectedPill
                    TunnelState.CONNECTING -> Color(0xFFFFF7ED)
                    TunnelState.ERROR -> Color(0xFFFEE2E2)
                    else -> Color(0xFFF1F5F9)
                },
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                when (vpnSession.state) {
                                    TunnelState.CONNECTED -> NexusSuccessGreen
                                    TunnelState.CONNECTING -> Color(0xFFF97316)
                                    TunnelState.ERROR -> NexusErrorRed
                                    else -> Color(0xFF94A3B8)
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (vpnSession.state) {
                            TunnelState.CONNECTED -> "CONNECTED - WireGuard Secure"
                            TunnelState.CONNECTING -> "CONNECTING..."
                            TunnelState.ERROR -> "CONNECTION FAILED"
                            TunnelState.DISCONNECTING -> "DISCONNECTING..."
                            TunnelState.DISCONNECTED -> "DISCONNECTED"
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (vpnSession.state) {
                            TunnelState.CONNECTED -> NexusSuccessGreen
                            TunnelState.CONNECTING -> Color(0xFFC2410C)
                            TunnelState.ERROR -> NexusErrorRed
                            else -> NexusTextSecondary
                        }
                    )
                }
            }

            // Duration Uptime
            Text(
                text = if (isConnected) formatUptime(vpnSession.durationSeconds) else "00:00:00",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = NexusNavyDark
            )
            Text(
                text = if (isConnected) "Session Uptime" else "Tap power button to connect",
                fontSize = 13.sp,
                color = NexusTextSecondary
            )
        }

        // 2. Central Pulsing Power Button
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(240.dp)
                .padding(vertical = 16.dp)
        ) {
            // Outer Halo Rings
            if (isConnected || isConnecting) {
                Box(
                    modifier = Modifier
                        .size(220.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(
                            if (isConnected) NexusCyan.copy(alpha = 0.15f)
                            else NexusRoyalBlue.copy(alpha = 0.15f)
                        )
                )
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .clip(CircleShape)
                        .background(
                            if (isConnected) NexusCyan.copy(alpha = 0.25f)
                            else NexusRoyalBlue.copy(alpha = 0.25f)
                        )
                )
            }

            // Central Glowing Button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(150.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = if (isConnected) listOf(NexusCyan, NexusRoyalBlue)
                            else if (isConnecting) listOf(Color(0xFF38BDF8), NexusRoyalBlue)
                            else listOf(Color(0xFFFFFFFF), Color(0xFFF1F5F9))
                        )
                    )
                    .border(
                        width = 4.dp,
                        color = if (isConnected) NexusCyan else Color(0xFFCBD5E1),
                        shape = CircleShape
                    )
                    .clickable {
                        if (isConnected) {
                            NexusVpnService.stopVpn(context)
                        } else {
                            onRequestVpnPermission()
                        }
                    }
                    .testTag("vpn_power_button")
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = "VPN Power Toggle",
                        tint = if (isConnected || isConnecting) Color.White else NexusRoyalBlue,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isConnected) "DISCONNECT" else if (isConnecting) "WAIT..." else "CONNECT",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isConnected || isConnecting) Color.White else NexusRoyalBlue
                    )
                }
            }
        }

        // 3. Real-Time Telemetry Cards
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Server Selection Pill Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, NexusCardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectServerClicked() }
                    .testTag("server_selector_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = selectedServer.flagEmoji.ifBlank { "🌐" },
                            fontSize = 28.sp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = selectedServer.name.ifBlank { "Singapore - SG01 (Fast)" },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = NexusTextPrimary
                                )
                                if (selectedServer.isPremium) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFFFEF3C7)
                                    ) {
                                        Text(
                                            text = "VIP",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFD97706),
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = "${selectedServer.countryName.ifBlank { "Singapore" }} • ${selectedServer.pingMs} ms",
                                fontSize = 12.sp,
                                color = NexusTextSecondary
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFF1F5F9),
                        modifier = Modifier.padding(4.dp)
                    ) {
                        Text(
                            text = "Change",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = NexusRoyalBlue,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Network Stats: Download & Upload Bandwidth
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NexusCardBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFE0EDFF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowDownward,
                                contentDescription = "Download",
                                tint = NexusRoyalBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Download", fontSize = 11.sp, color = NexusTextSecondary)
                            Text(
                                text = formatBytes(vpnSession.bytesOut),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = NexusTextPrimary
                            )
                        }
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NexusCardBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFD7F8FF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowUpward,
                                contentDescription = "Upload",
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Upload", fontSize = 11.sp, color = NexusTextSecondary)
                            Text(
                                text = formatBytes(vpnSession.bytesIn),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = NexusTextPrimary
                            )
                        }
                    }
                }
            }

            // Security & Virtual IP Status
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, NexusCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Shield",
                            tint = if (isConnected) NexusSuccessGreen else NexusTextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (isConnected) "Encrypted Tunnel (ChaCha20)" else "Protection Disabled",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = NexusTextPrimary
                            )
                            Text(
                                text = if (isConnected) "IP: ${vpnSession.assignedIp.ifBlank { "10.66.0.2" }}" else "Your Real IP is Exposed",
                                fontSize = 11.sp,
                                color = if (isConnected) NexusSuccessGreen else NexusErrorRed
                            )
                        }
                    }

                    Icon(
                        imageVector = if (isConnected) Icons.Default.CheckCircle else Icons.Default.Public,
                        contentDescription = "Status Icon",
                        tint = if (isConnected) NexusSuccessGreen else NexusTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

private fun formatUptime(seconds: Long): String {
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return String.format("%02d:%02d:%02d", hrs, mins, secs)
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0.0 KB"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format("%.2f GB", gb)
        mb >= 1.0 -> String.format("%.1f MB", mb)
        else -> String.format("%.1f KB", kb)
    }
}
