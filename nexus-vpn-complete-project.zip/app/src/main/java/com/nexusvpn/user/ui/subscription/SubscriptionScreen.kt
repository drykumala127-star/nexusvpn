package com.nexusvpn.user.ui.subscription

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.NexusCardBorder
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusLightBackground
import com.example.ui.theme.NexusNavyDark
import com.example.ui.theme.NexusRoyalBlue
import com.example.ui.theme.NexusSuccessGreen
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.nexusvpn.core.data.models.NexusUser
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class PricingPlan(
    val id: String,
    val name: String,
    val durationText: String,
    val price: Long,
    val priceFormatted: String,
    val isBestValue: Boolean = false,
    val features: List<String>
)

@Composable
fun SubscriptionScreen(
    user: NexusUser?,
    onClaimTrial: (onResult: (Boolean, String) -> Unit) -> Unit,
    onPayWithQris: (plan: PricingPlan) -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var isClaimingTrial by remember { mutableStateOf(false) }
    var trialMessage by remember { mutableStateOf<String?>(null) }
    var selectedPlanForPayment by remember { mutableStateOf<PricingPlan?>(null) }

    val plans = remember {
        listOf(
            PricingPlan(
                id = "plan_1_month",
                name = "1 Bulan Premium",
                durationText = "30 Hari Akses Penuh",
                price = 29000L,
                priceFormatted = "Rp 29.000",
                features = listOf(
                    "Akses Seluruh Node VIP (Tokyo, SG, US, UK)",
                    "Bandwidth Tanpa Batas (Unlimited)",
                    "Kecepatan Hingga 1 Gbps WireGuard",
                    "Bypass Blokir Streaming & Game"
                )
            ),
            PricingPlan(
                id = "plan_3_months",
                name = "3 Bulan Hemat",
                durationText = "90 Hari Akses VIP",
                price = 69000L,
                priceFormatted = "Rp 69.000",
                isBestValue = true,
                features = listOf(
                    "Hemat 20% Dibandingkan Bulanan",
                    "Prioritas Routing Dedicated Tunnel",
                    "Akses Semua Lokasi Server VIP",
                    "Dukungan CS 24/7"
                )
            ),
            PricingPlan(
                id = "plan_1_year",
                name = "1 Tahun Sultan",
                durationText = "365 Hari Akses VIP",
                price = 199000L,
                priceFormatted = "Rp 199.000",
                features = listOf(
                    "Hemat 45% (Hanya Rp 16rb / bulan)",
                    "Akses Server Paling Cepat & Eksklusif",
                    "Fitur Dedicated IP saat rilis",
                    "Keamanan Enkripsi Maksimal"
                )
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NexusLightBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFFFEF3C7),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Text(
                        text = "⭐ NEXUS VIP SUBSCRIPTION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD97706),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
                Text(
                    text = "Buka Kecepatan Tanpa Batas",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = NexusNavyDark
                )
                Text(
                    text = "Koneksi WireGuard ultra cepat dengan enkripsi tingkat militer",
                    fontSize = 13.sp,
                    color = NexusTextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        }

        // 1. Klaim Trial 24 Jam Banner (Jika belum digunakan)
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, NexusCyan),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Gratis 24 Jam VIP Trial",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = NexusNavyDark
                            )
                            Text(
                                text = if (user?.isTrialUsed == true) "Masa trial telah digunakan di akun ini"
                                else "Coba seluruh server VIP kecepatan tinggi tanpa biaya",
                                fontSize = 12.sp,
                                color = NexusTextSecondary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE0EDFF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.HourglassTop, contentDescription = "Trial", tint = NexusRoyalBlue)
                        }
                    }

                    trialMessage?.let { msg ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = msg,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (msg.contains("berhasil", true)) NexusSuccessGreen else Color(0xFFEF4444)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            isClaimingTrial = true
                            onClaimTrial { success, msg ->
                                isClaimingTrial = false
                                trialMessage = msg
                            }
                        },
                        enabled = user?.isTrialUsed != true && !isClaimingTrial,
                        colors = ButtonDefaults.buttonColors(containerColor = NexusRoyalBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("claim_trial_button")
                    ) {
                        if (isClaimingTrial) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                        } else {
                            Text(
                                text = if (user?.isTrialUsed == true) "TRIAL SUDAH DIGUNAKAN" else "KLAIM TRIAL 24 JAM",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // 2. Paket Berlangganan QRIS
        items(plans.size) { index ->
            val plan = plans[index]
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(
                    width = if (plan.isBestValue) 2.dp else 1.dp,
                    color = if (plan.isBestValue) NexusRoyalBlue else NexusCardBorder
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    if (plan.isBestValue) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = NexusRoyalBlue,
                            modifier = Modifier.padding(bottom = 8.dp)
                        ) {
                            Text(
                                text = "PILIHAN TERBAIK (HEMAT 20%)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = plan.name,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = NexusNavyDark
                            )
                            Text(
                                text = plan.durationText,
                                fontSize = 12.sp,
                                color = NexusTextSecondary
                            )
                        }

                        Text(
                            text = plan.priceFormatted,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NexusRoyalBlue
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    plan.features.forEach { feature ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Check",
                                tint = NexusSuccessGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = feature,
                                fontSize = 13.sp,
                                color = NexusTextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { selectedPlanForPayment = plan },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (plan.isBestValue) NexusRoyalBlue else Color(0xFF0F172A)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("buy_plan_${plan.id}")
                    ) {
                        Icon(Icons.Default.QrCode2, contentDescription = "QRIS", tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "BAYAR DENGAN QRIS",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }

    // Modal QRIS Payment
    selectedPlanForPayment?.let { plan ->
        QrisPaymentModal(
            plan = plan,
            onDismiss = { selectedPlanForPayment = null }
        )
    }
}

@Composable
fun QrisPaymentModal(
    plan: PricingPlan,
    onDismiss: () -> Unit
) {
    var isCheckingStatus by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf<String?>("Menunggu Pembayaran (Scan QR)") }
    val scope = rememberCoroutineScope()

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Pembayaran QRIS Resmi",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = NexusNavyDark
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = NexusTextSecondary)
                    }
                }

                Text(
                    text = "${plan.name} • ${plan.priceFormatted}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NexusRoyalBlue,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Simulated Authentic QR Code View (Rendered with stylized matrix patterns)
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFF8FAFC))
                        .border(1.5.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "QRIS Code",
                            tint = NexusNavyDark,
                            modifier = Modifier.size(130.dp)
                        )
                        Text(
                            text = "NEXUS VPN QRIS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NexusTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Buka BCA Mobile, GoPay, OVO, Dana, ShopeePay atau M-Banking Anda lalu scan QRIS di atas.",
                    fontSize = 11.sp,
                    color = NexusTextSecondary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F5F9),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Ref Order:", fontSize = 11.sp, color = NexusTextSecondary)
                        Text("NEXUS-${System.currentTimeMillis().toString().takeLast(6)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NexusTextPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                statusText?.let {
                    Text(
                        text = it,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (it.contains("Lunas", true)) NexusSuccessGreen else Color(0xFFD97706)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        isCheckingStatus = true
                        scope.launch {
                            delay(1500)
                            isCheckingStatus = false
                            statusText = "Menunggu webhook konfirmasi dari gateway..."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NexusRoyalBlue),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                ) {
                    if (isCheckingStatus) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                    } else {
                        Text("CEK STATUS PEMBAYARAN", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
