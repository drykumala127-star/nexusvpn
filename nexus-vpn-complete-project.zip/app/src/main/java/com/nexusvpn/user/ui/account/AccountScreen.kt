package com.nexusvpn.user.ui.account

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NexusCardBorder
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusLightBackground
import com.example.ui.theme.NexusNavyDark
import com.example.ui.theme.NexusRoyalBlue
import com.example.ui.theme.NexusSuccessGreen
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.nexusvpn.core.data.models.NexusUser
import kotlinx.coroutines.launch

@Composable
fun AccountScreen(
    user: NexusUser?,
    isGuest: Boolean,
    onLoginWithEmail: (email: String, pass: String, (Boolean, String) -> Unit) -> Unit,
    onSignUpWithEmail: (email: String, pass: String, name: String, (Boolean, String) -> Unit) -> Unit,
    onUpgradeGuest: (email: String, pass: String, (Boolean, String) -> Unit) -> Unit,
    onSignOut: () -> Unit,
    onOpenAdminPortal: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var isUpgrading by remember { mutableStateOf(false) }
    var upgradeEmail by remember { mutableStateOf("") }
    var upgradePassword by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    // Login/Register state for non-guests or manual switcher
    var isRegisterMode by remember { mutableStateOf(false) }
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var nameInput by remember { mutableStateOf("") }
    var isAuthLoading by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusLightBackground)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Akun & Keamanan",
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            color = NexusNavyDark
        )

        // 1. Kartu Profil Pengguna
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(if (user?.isPremiumActive == true) Color(0xFFFEF3C7) else Color(0xFFE0EDFF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (user?.isPremiumActive == true) Icons.Default.Star else Icons.Default.Person,
                            contentDescription = "Avatar",
                            tint = if (user?.isPremiumActive == true) Color(0xFFD97706) else NexusRoyalBlue,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = user?.displayName?.ifBlank { if (isGuest) "Guest User (Tamu)" else "Nexus Member" } ?: "Guest User",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = NexusNavyDark
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (user?.isPremiumActive == true) Color(0xFFFEF3C7) else Color(0xFFF1F5F9)
                            ) {
                                Text(
                                    text = if (user?.isPremiumActive == true) "VIP PREMIUM" else "FREE",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (user?.isPremiumActive == true) Color(0xFFD97706) else NexusTextSecondary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = if (isGuest) "UID: ${user?.uid?.take(10) ?: "guest"}... (Belum Terdaftar)"
                            else user?.email ?: "Akun Terdaftar",
                            fontSize = 12.sp,
                            color = NexusTextSecondary
                        )
                    }
                }
            }
        }

        // 2. UPGRADE GUEST KE AKUN PERMANEN (UID PRESERVED)
        if (isGuest) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, NexusSuccessGreen),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Upgrade, contentDescription = "Upgrade", tint = NexusSuccessGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Upgrade Akun Guest ke Permanen",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = NexusNavyDark
                        )
                    }
                    Text(
                        text = "Hubungkan akun tamu Anda dengan email & password agar UID dan sisa masa aktif langganan tidak hilang jika aplikasi dihapus.",
                        fontSize = 12.sp,
                        color = NexusTextSecondary,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    OutlinedTextField(
                        value = upgradeEmail,
                        onValueChange = { upgradeEmail = it },
                        label = { Text("Email Baru") },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = "Email", tint = NexusTextSecondary) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = upgradePassword,
                        onValueChange = { upgradePassword = it },
                        label = { Text("Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = "Password", tint = NexusTextSecondary) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    statusMessage?.let {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(it, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NexusRoyalBlue)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (upgradeEmail.isNotBlank() && upgradePassword.isNotBlank()) {
                                isUpgrading = true
                                onUpgradeGuest(upgradeEmail, upgradePassword) { success, msg ->
                                    isUpgrading = false
                                    statusMessage = msg
                                }
                            }
                        },
                        enabled = !isUpgrading && upgradeEmail.isNotBlank() && upgradePassword.length >= 6,
                        colors = ButtonDefaults.buttonColors(containerColor = NexusSuccessGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("upgrade_guest_button")
                    ) {
                        if (isUpgrading) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                        } else {
                            Text("SIMPAN & HUBUNGKAN AKUN", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // 3. Portals & Access Control
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Akses Khusus",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = NexusNavyDark
                )
                Text(
                    text = "Pengelolaan server fleet, peer WireGuard, dan verifikasi transaksi",
                    fontSize = 12.sp,
                    color = NexusTextSecondary,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                OutlinedButton(
                    onClick = { onOpenAdminPortal() },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("open_admin_portal_button")
                ) {
                    Icon(Icons.Default.Security, contentDescription = "Admin", tint = NexusRoyalBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "BUKA NEXUS ADMIN PORTAL",
                        fontWeight = FontWeight.Bold,
                        color = NexusRoyalBlue,
                        fontSize = 13.sp
                    )
                }

                if (!isGuest) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onSignOut,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = "Logout", tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("KELUAR (SIGN OUT)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
