PETUNJUK UNGGAH KONFIGURASI FIREBASE UNTUK NEXUS VPN USER:

1. Buka Firebase Console: https://console.firebase.google.com/
2. Masuk ke project "NEXUS VPN".
3. Di Project Settings > General, pilih App dengan Package Name:
   com.nexusvpn.app
4. Unduh file "google-services.json".
5. Unggah file tersebut ke folder ini dengan nama:
   /firebase/user/google-services.json
   (Atau langsung ke root modul aplikasi: /app/google-services.json)

Catatan Keamanan:
- Jangan mengubah isi package_name di dalam file JSON.
- Jangan gunakan file dari project lain.
