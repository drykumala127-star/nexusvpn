PETUNJUK UNGGAH KONFIGURASI FIREBASE UNTUK NEXUS VPN ADMIN:

1. Buka Firebase Console: https://console.firebase.google.com/
2. Masuk ke project "NEXUS VPN".
3. Di Project Settings > General, pilih App dengan Package Name:
   com.nexusvpn.admin
4. Unduh file "google-services.json".
5. Unggah file tersebut ke folder ini dengan nama:
   /firebase/admin/google-services.json

Catatan Keamanan:
- Pastikan package_name di dalam file ini adalah: "com.nexusvpn.admin".
- Jangan sampai tertukar dengan file untuk User App ("com.nexusvpn.app").
- Sistem validasi otomatis akan memeriksa package_name saat file diunggah.
