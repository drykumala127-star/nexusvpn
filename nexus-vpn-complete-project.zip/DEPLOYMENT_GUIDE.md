# PANDUAN DEPLOYMENT & CHECKLIST KEAMANAN FIREBASE NEXUS VPN

Dokumen ini menjelaskan langkah deployment dan status verifikasi seluruh konfigurasi Firebase untuk aplikasi **NEXUS VPN** (`nexus-vpn-7a261`).

---

## 1. Audit Kepatuhan Keamanan (11 Kriteria Wajib)

| No | Kriteria Keamanan & Arsitektur | Status Kode | Catatan Konfigurasi |
|---|---|---|---|
| 1 | **Guest menggunakan Anonymous Auth** | ✅ Selesai | `AuthManager.kt` otomatis login anonymous jika belum ada sesi. |
| 2 | **Akun Premium wajib akun terdaftar** | ✅ Selesai | `createQrisInvoice` & `qrisPaymentWebhook` menolak jika user adalah Guest. |
| 3 | **Trial 24 Jam divalidasi server-side** | ✅ Selesai | `claimTrial24h` di Cloud Functions dengan hash SHA-256 device fingerprint. |
| 4 | **User tidak bisa ubah status premium sendiri** | ✅ Selesai | `firestore.rules` mengunci field `subscriptionPlan` & `subscriptionExpiresAt`. |
| 5 | **User tidak bisa angkat diri jadi ADMIN** | ✅ Selesai | `firestore.rules` membatasi `role == 'user'` pada saat buat akun & kunci saat edit. |
| 6 | **Transaksi PAID hanya via Webhook Resmi** | ✅ Selesai | Client hanya bisa read transaksi miliknya. Status PAID hanya diubah Cloud Functions. |
| 7 | **Firestore Rules Least Privilege** | ✅ Selesai | Semua koleksi dikunci per-user (`isOwner`) atau khusus `isAdmin`. |
| 8 | **Verifikasi Firebase ID Token di Backend** | ✅ Selesai | Semua callable function memeriksa `context.auth` sebelum memproses logika. |
| 9 | **Audit Log untuk Admin** | ✅ Selesai | Koleksi `audit_logs` bersifat *append-only* (tidak bisa dihapus/diubah). |
| 10 | **Firebase App Check di Android** | ✅ Selesai | `NexusAppCheck.kt` diaktifkan di `MainActivity.onCreate()`. |
| 11 | **Zero Secret di APK** | ✅ Selesai | Private key WireGuard VPS & Secret Webhook hanya ada di Cloud Functions `.env`. |

---

## 2. Hal yang Masih Belum Lengkap (Wajib Diaktifkan di Firebase Console)

Aplikasi **BELUM DAPAT DISEBUT PRODUCTION-READY** sampai Anda mengaktifkan 3 hal berikut di Firebase Console:

1. **Aktifkan Anonymous Authentication**:
   - Buka Firebase Console > **Authentication** > tab **Sign-in method**.
   - Klik **Anonymous** lalu klik **Enable** dan **Save**.
   *(Jika belum diaktifkan, login guest akan ditolak oleh Firebase).*
2. **Aktifkan Email/Password & Google Sign-In**:
   - Masih di tab **Sign-in method**, aktifkan **Email/Password**.
   - Aktifkan **Google** dan pilih email support proyek Anda.
3. **Konfigurasi Environment Secret untuk Webhook QRIS**:
   - Saat deploy Cloud Functions, tentukan nilai rahasia `QRIS_WEBHOOK_SECRET` yang didapatkan dari dashboard payment gateway (Midtrans / Xendit / Tripay).
4. **Registrasi SHA-256 untuk App Check (Play Integrity)**:
   - Di Firebase Console > **App Check**, daftarkan SHA-256 release keystore Anda untuk kedua package (`com.nexusvpn.app` dan `com.nexusvpn.admin`).

---

## 3. Langkah Deployment Backend & Rules ke Firebase

### A. Deploy Firestore Security Rules
Jalankan perintah berikut di terminal (atau via Firebase CLI):
```bash
firebase deploy --only firestore:rules
```

### B. Deploy Cloud Functions
Masuk ke direktori backend:
```bash
cd backend/functions
npm install
firebase deploy --only functions
```

### C. Set Environment Secret di Cloud Functions
```bash
firebase functions:config:set qris.webhook_secret="KUNCI_RAHASIA_DARI_PAYMENT_GATEWAY"
```
atau pada Cloud Functions v2:
```bash
firebase functions:secrets:set QRIS_WEBHOOK_SECRET
```
