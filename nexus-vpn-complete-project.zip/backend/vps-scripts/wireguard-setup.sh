#!/bin/bash
# ==============================================================================
# NEXUS VPN - Script Konfigurasi Server WireGuard Resmi (Ubuntu 22.04 / 24.04 LTS)
# ==============================================================================
# Jalankan script ini di VPS Anda sebagai ROOT (misal di DigitalOcean, Linode, AWS):
# curl -O https://raw.githubusercontent.com/.../wireguard-setup.sh && bash wireguard-setup.sh
# ==============================================================================

set -e

echo "=== [1/5] Memperbarui Sistem & Memasang WireGuard ==="
apt update && apt upgrade -y
apt install -y wireguard wireguard-tools iptables qrencode curl ufw

echo "=== [2/5] Mengaktifkan IP Forwarding Kernel ==="
sed -i 's/#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/' /etc/sysctl.conf
if ! grep -q "net.ipv4.ip_forward=1" /etc/sysctl.conf; then
    echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
fi
sysctl -p

echo "=== [3/5] Membuat Kunci Kriptografi Server WireGuard ==="
mkdir -p /etc/wireguard
cd /etc/wireguard
umask 077
wg genkey | tee server_private.key | wg pubkey > server_public.key

SERVER_PRIV_KEY=$(cat server_private.key)
SERVER_PUB_KEY=$(cat server_public.key)

# Deteksi otomatis interface kartu jaringan utama (biasanya eth0, ens3, atau ens4)
MAIN_NET_IF=$(ip -4 route ls | grep default | grep -Po '(?<=dev )(\S+)' | head -1)

echo "=== [4/5] Membuat Konfigurasi wg0.conf ==="
cat > /etc/wireguard/wg0.conf <<EOF
[Interface]
Address = 10.66.0.1/24
ListenPort = 51820
PrivateKey = ${SERVER_PRIV_KEY}
SaveConfig = false

# Aturan Routing Firewall & NAT Masquerade
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o ${MAIN_NET_IF} -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o ${MAIN_NET_IF} -j MASQUERADE
EOF

chmod 600 /etc/wireguard/wg0.conf

echo "=== [5/5] Mengaktifkan Layanan WireGuard ==="
systemctl enable wg-quick@wg0
systemctl start wg-quick@wg0

# Buka Port 51820 UDP di Firewall
ufw allow 51820/udp || true

SERVER_IP=$(curl -s https://api.ipify.org || hostname -I | awk '{print $1}')

echo ""
echo "=========================================================================="
echo "🎉 SERVER WIREGUARD NEXUS VPN BERHASIL DIAKTIFKAN!"
echo "=========================================================================="
echo "IP Server (Endpoint) : ${SERVER_IP}"
echo "Port                 : 51820 (UDP)"
echo "Server Public Key    : ${SERVER_PUB_KEY}"
echo "DNS Aman             : 1.1.1.1, 8.8.8.8"
echo "=========================================================================="
echo "Salin 'Server Public Key' dan 'IP Server' di atas ke menu Admin NEXUS VPN!"
echo "=========================================================================="
