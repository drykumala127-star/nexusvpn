# 📱 Panduan Cloud Build Android NEXUS VPN Menggunakan HP Android (Chrome)

Panduan ini disusun khusus agar Anda dapat membangun (build) APK **NEXUS VPN USER** dan **NEXUS VPN ADMIN** sepenuhnya di cloud via **GitHub Actions** tanpa memerlukan komputer atau Android Studio di perangkat lokal.

---

## 🏗️ 1. Persiapan Repositori GitHub dari Browser HP Android

1. Buka browser **Google Chrome** di HP Android Anda.
2. Masuk ke [https://github.com](https://github.com).
3. Klik ikon `+` di pojok kanan atas, lalu pilih **New repository**.
4. Beri nama repositori, misalnya: `nexus-vpn`.
5. Pilih visibilitas **Private** (disarankan) atau **Public**, lalu klik **Create repository**.

---

## 📤 2. Cara Mengunggah Source Code dari HP

### Cara A: Mengunggah Langsung dari Browser Chrome HP (Paling Mudah)
1. Unduh arsip source code ZIP dari link yang telah disediakan.
2. Ekstrak ZIP di HP menggunakan file manager bawaan (atau aplikasi ZArchiver / RAR).
3. Buka repositori GitHub Anda di browser Chrome.
4. Aktifkan mode **Situs Desktop / Desktop site** di menu titik tiga pojok kanan atas browser Chrome.
5. Klik tombol **Add file** > **Upload files**.
6. Pilih folder dan file proyek (termasuk folder `.github`, `app`, `nexus-vpn-admin`, `backend`, `firebase`, `gradle`, serta file `build.gradle.kts`, `settings.gradle.kts`, dll.).
7. Klik tombol hijau **Commit changes**.

### Cara B: Menggunakan Termux di Android (Untuk Pengguna Mahir)
```bash
pkg install git
git init
git remote add origin https://github.com/USERNAME/nexus-vpn.git
git add .
git commit -m "Initial commit NEXUS VPN"
git branch -M main
git push -u origin main
```

---

## 🔐 3. Konfigurasi GitHub Secrets untuk Release APK (Opsional)

Secara default, workflow GitHub Actions akan otomatis membangun **Debug APK** yang siap langsung di-install di HP tanpa perlu mendaftarkan kunci signing.

Namun jika Anda ingin menghasilkan **Signed Release APK** untuk distribusi resmi:
1. Buka repositori GitHub di Chrome HP > Buka menu tab **Settings**.
2. Di menu samping kiri, pilih **Secrets and variables** > **Actions**.
3. Klik tombol hijau **New repository secret**.
4. Tambahkan 4 secret berikut (satu per satu):
   * `KEYSTORE_BASE64`: String base64 dari file keystore `.jks` Anda.
   * `KEYSTORE_PASSWORD`: Password keystore.
   * `KEY_ALIAS`: Alias key (contoh: `upload`).
   * `KEY_PASSWORD`: Password key alias.

> ⚠️ **Catatan Keamanan**: Jangan pernah memasukkan file keystore `.jks` atau password langsung ke dalam commit source code. GitHub Secrets mengenkripsi data ini secara aman di cloud runner.

---

## ⚡ 4. Cara Menjalankan Build dari Browser HP

1. Buka tab **Actions** di repositori GitHub Anda.
2. Di sisi kiri layar, Anda akan melihat 2 workflow terpisah:
   * **Build NEXUS VPN USER APK**: Untuk aplikasi pengguna (`com.nexusvpn.app`).
   * **Build NEXUS VPN ADMIN APK**: Untuk aplikasi pengelola/admin (`com.nexusvpn.admin`).
3. Klik pada salah satu workflow yang ingin Anda bangun.
4. Klik tombol dropdown **Run workflow** di sebelah kanan.
5. Pilih branch (`main`) dan jenis APK:
   * `debug` (default, cepat & langsung bisa di-install)
   * `release` (memerlukan GitHub Secrets)
   * `both` (membangun versi debug dan release sekaligus)
6. Klik tombol hijau **Run workflow**.

---

## 🔍 5. Memantau Proses Build & Melihat Error Log

1. Setelah tombol *Run workflow* ditekan, akan muncul run baru berstatus kuning (sedang berjalan).
2. Ketuk run tersebut untuk melihat progres tiap tahapan:
   * Setup JDK 17 (Temurin)
   * Setup Gradle Environment
   * Clean & Verify Project (`./gradlew clean`, `compileDebugKotlin`)
   * Assemble APK
   * Upload Artifact
3. Waktu build biasanya membutuhkan waktu **2 hingga 4 menit**.
4. Jika terjadi error:
   * Step yang gagal akan ditandai dengan ikon silang merah (❌).
   * Ketuk pada step tersebut untuk membuka log teks lengkap guna mengetahui baris atau penyebab error secara mendetail.

---

## 📥 6. Cara Mengunduh APK ke HP Android

1. Ketika workflow selesai, ikon status akan berubah menjadi centang hijau (✅).
2. Gulir ke bagian paling bawah halaman run tersebut ke bagian **Artifacts**.
3. Anda akan melihat file artifact:
   * `NEXUS-VPN-USER-debug-apk.zip` (atau versi signed release jika memilih release)
   * `NEXUS-VPN-ADMIN-debug-apk.zip`
4. Ketuk nama artifact untuk mengunduh ke HP Anda.
5. Ekstrak file `.zip` yang terunduh di HP, Anda akan mendapatkan file `.apk` siap install di Android Anda!
