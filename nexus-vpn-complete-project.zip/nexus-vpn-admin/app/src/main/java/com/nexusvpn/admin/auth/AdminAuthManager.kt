package com.nexusvpn.admin.auth

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

class AdminAuthManager {

    companion object {
        private const val TAG = "AdminAuthManager"
    }

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    private val _currentAdmin = MutableStateFlow<FirebaseUser?>(auth.currentUser)
    val currentAdmin: StateFlow<FirebaseUser?> = _currentAdmin.asStateFlow()

    private val _isAdminAuthenticated = MutableStateFlow<Boolean>(false)
    val isAdminAuthenticated: StateFlow<Boolean> = _isAdminAuthenticated.asStateFlow()

    init {
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            _currentAdmin.value = user
            if (user == null) {
                _isAdminAuthenticated.value = false
            }
        }
    }

    suspend fun signInAdmin(email: String, password: String): Result<FirebaseUser> {
        return try {
            val authResult = auth.signInWithEmailAndPassword(email.trim(), password).await()
            val user = authResult.user ?: throw IllegalStateException("Otentikasi Firebase gagal.")

            // Verifikasi Server-Side Role ADMIN di Firestore
            val userDoc = firestore.collection("users").document(user.uid).get().await()
            val role = userDoc.getString("role")

            if (role != "admin") {
                auth.signOut()
                _isAdminAuthenticated.value = false
                throw SecurityException("Akses Ditolak: Akun '${email}' tidak terdaftar sebagai Administrator NEXUS VPN.")
            }

            // Catat log sukses login admin
            firestore.collection("audit_logs").add(
                mapOf(
                    "adminUid" to user.uid,
                    "adminEmail" to (user.email ?: email),
                    "action" to "ADMIN_LOGIN",
                    "target" to "NEXUS Admin Console",
                    "details" to "Login berhasil via Admin Portal App",
                    "timestamp" to com.google.firebase.Timestamp.now()
                )
            )

            _isAdminAuthenticated.value = true
            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "Admin login error: ${e.message}", e)
            _isAdminAuthenticated.value = false
            Result.failure(e)
        }
    }

    fun signOutAdmin() {
        auth.signOut()
        _isAdminAuthenticated.value = false
    }
}
