package com.nexusvpn.admin.ui.screens.trial

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusvpn.admin.data.AdminRepository
import com.nexusvpn.admin.data.models.TrialConfig
import com.nexusvpn.admin.ui.theme.AdminBg
import com.nexusvpn.admin.ui.theme.AdminBorder
import com.nexusvpn.admin.ui.theme.AdminCard
import com.nexusvpn.admin.ui.theme.AdminCyan
import com.nexusvpn.admin.ui.theme.AdminGold
import com.nexusvpn.admin.ui.theme.AdminSuccess
import com.nexusvpn.admin.ui.theme.AdminTextPrimary
import com.nexusvpn.admin.ui.theme.AdminTextSecondary
import kotlinx.coroutines.launch

@Composable
fun TrialManagementScreen(
    repository: AdminRepository,
    modifier: Modifier = Modifier
) {
    val trialConfig by repository.observeTrialConfig().collectAsState(initial = TrialConfig())
    var trialHours by remember(trialConfig.trialHours) { mutableStateOf(trialConfig.trialHours.toString()) }
    var isEnabled by remember(trialConfig.isTrialEnabled) { mutableStateOf(trialConfig.isTrialEnabled) }
    var maxClaims by remember(trialConfig.maxClaimsPerDevice) { mutableStateOf(trialConfig.maxClaimsPerDevice.toString()) }
    var isSavedNotification by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AdminBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = "SERVER-SIDE TRIAL & ANTI-FRAUD RULES",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = AdminTextPrimary
            )
            Text(
                text = "Enforce device hardware fingerprints & 24h limits",
                fontSize = 12.sp,
                color = AdminCyan
            )
        }

        if (isSavedNotification) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AdminSuccess.copy(alpha = 0.2f),
                border = androidx.compose.foundation.BorderStroke(1.dp, AdminSuccess)
            ) {
                Text(
                    text = "✓ Aturan Trial berhasil diperbarui dan disinkronkan ke Cloud Functions.",
                    color = AdminSuccess,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = AdminCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Global Trial Availability", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = AdminTextPrimary)
                        Text("Allow new users to claim 24h free VIP", fontSize = 12.sp, color = AdminTextSecondary)
                    }

                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { isEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = AdminSuccess,
                            checkedTrackColor = AdminSuccess.copy(alpha = 0.3f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = trialHours,
                    onValueChange = { trialHours = it },
                    label = { Text("Trial Duration (Hours)", color = AdminTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.HourglassBottom, contentDescription = null, tint = AdminCyan) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AdminTextPrimary,
                        unfocusedTextColor = AdminTextPrimary,
                        focusedBorderColor = AdminGold,
                        unfocusedBorderColor = AdminBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = maxClaims,
                    onValueChange = { maxClaims = it },
                    label = { Text("Max Claims Per Device Hardware Hash", color = AdminTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Security, contentDescription = null, tint = AdminGold) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AdminTextPrimary,
                        unfocusedTextColor = AdminTextPrimary,
                        focusedBorderColor = AdminGold,
                        unfocusedBorderColor = AdminBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        scope.launch {
                            repository.saveTrialConfig(
                                TrialConfig(
                                    trialHours = trialHours.toIntOrNull() ?: 24,
                                    isTrialEnabled = isEnabled,
                                    maxClaimsPerDevice = maxClaims.toIntOrNull() ?: 1
                                )
                            )
                            isSavedNotification = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AdminGold, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("SAVE TRIAL POLICIES", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        // Informational Box
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E3D)),
            border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("🛡️ Server-Side Anti-Abuse Protection", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AdminGold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Aplikasi NEXUS VPN menghitung hash kriptografis SHA-256 dari hardware ID pengguna saat mengklaim trial. Jika pengguna menghapus aplikasi atau login dengan akun baru pada perangkat yang sama, backend otomatis menolak klaim trial berikutnya.",
                    fontSize = 11.sp,
                    color = AdminTextSecondary,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
