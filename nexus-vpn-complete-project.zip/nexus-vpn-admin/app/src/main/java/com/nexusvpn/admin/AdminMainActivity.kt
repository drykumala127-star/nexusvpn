package com.nexusvpn.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusvpn.admin.auth.AdminAuthManager
import com.nexusvpn.admin.data.AdminRepository
import com.nexusvpn.admin.ui.screens.announcements.AnnouncementScreen
import com.nexusvpn.admin.ui.screens.audit.AuditLogScreen
import com.nexusvpn.admin.ui.screens.dashboard.AdminDashboardScreen
import com.nexusvpn.admin.ui.screens.login.AdminLoginScreen
import com.nexusvpn.admin.ui.screens.peers.PeerManagerScreen
import com.nexusvpn.admin.ui.screens.plans.PremiumPlansScreen
import com.nexusvpn.admin.ui.screens.servers.ServerManagerScreen
import com.nexusvpn.admin.ui.screens.settings.AdminSettingsScreen
import com.nexusvpn.admin.ui.screens.transactions.TransactionScreen
import com.nexusvpn.admin.ui.screens.trial.TrialManagementScreen
import com.nexusvpn.admin.ui.screens.users.UserListScreen
import com.nexusvpn.admin.ui.theme.AdminBg
import com.nexusvpn.admin.ui.theme.AdminBorder
import com.nexusvpn.admin.ui.theme.AdminCard
import com.nexusvpn.admin.ui.theme.AdminCyan
import com.nexusvpn.admin.ui.theme.AdminGold
import com.nexusvpn.admin.ui.theme.AdminSurface
import com.nexusvpn.admin.ui.theme.AdminTextPrimary
import com.nexusvpn.admin.ui.theme.AdminTextSecondary
import com.nexusvpn.admin.ui.theme.NexusAdminTheme

class AdminMainActivity : ComponentActivity() {

    private val authManager by lazy { AdminAuthManager() }
    private val repository by lazy { AdminRepository() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            NexusAdminTheme {
                AdminAppRoot(
                    authManager = authManager,
                    repository = repository
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAppRoot(
    authManager: AdminAuthManager,
    repository: AdminRepository
) {
    val currentAdmin by authManager.currentAdmin.collectAsState()
    val isAuthenticated by authManager.isAdminAuthenticated.collectAsState()

    var currentTab by remember { mutableIntStateOf(0) }

    if (currentAdmin == null || !isAuthenticated) {
        AdminLoginScreen(
            authManager = authManager,
            onLoginSuccess = { currentTab = 0 }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (currentTab) {
                            0 -> "SYSTEM TELEMETRY"
                            1 -> "USER DIRECTORY"
                            2 -> "WIREGUARD NODES"
                            3 -> "ACTIVE PEERS"
                            4 -> "QRIS TRANSACTIONS"
                            5 -> "PLANS & TRIAL"
                            6 -> "BROADCAST & PUSH"
                            else -> "AUDIT & SECURITY"
                        },
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = AdminTextPrimary,
                        letterSpacing = 1.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AdminSurface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = AdminSurface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                    label = { Text("Overview", fontSize = 10.sp) },
                    colors = navItemColors()
                )
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    icon = { Icon(Icons.Default.People, contentDescription = "Users") },
                    label = { Text("Users", fontSize = 10.sp) },
                    colors = navItemColors()
                )
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    icon = { Icon(Icons.Default.Dns, contentDescription = "Nodes") },
                    label = { Text("Nodes", fontSize = 10.sp) },
                    colors = navItemColors()
                )
                NavigationBarItem(
                    selected = currentTab == 4,
                    onClick = { currentTab = 4 },
                    icon = { Icon(Icons.Default.QrCode, contentDescription = "QRIS") },
                    label = { Text("QRIS", fontSize = 10.sp) },
                    colors = navItemColors()
                )
                NavigationBarItem(
                    selected = currentTab == 5,
                    onClick = { currentTab = 5 },
                    icon = { Icon(Icons.Default.Star, contentDescription = "Plans") },
                    label = { Text("Plans", fontSize = 10.sp) },
                    colors = navItemColors()
                )
                NavigationBarItem(
                    selected = currentTab == 6,
                    onClick = { currentTab = 6 },
                    icon = { Icon(Icons.Default.Campaign, contentDescription = "Broadcast") },
                    label = { Text("Push", fontSize = 10.sp) },
                    colors = navItemColors()
                )
                NavigationBarItem(
                    selected = currentTab == 7,
                    onClick = { currentTab = 7 },
                    icon = { Icon(Icons.Default.Security, contentDescription = "Audit") },
                    label = { Text("Audit", fontSize = 10.sp) },
                    colors = navItemColors()
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(AdminBg)
                .padding(innerPadding)
        ) {
            when (currentTab) {
                0 -> AdminDashboardScreen(
                    repository = repository,
                    onNavigateToUsers = { currentTab = 1 },
                    onNavigateToServers = { currentTab = 2 },
                    onNavigateToTransactions = { currentTab = 4 },
                    onNavigateToAnnouncements = { currentTab = 6 },
                    onNavigateToAudit = { currentTab = 7 }
                )
                1 -> UserListScreen(repository = repository)
                2 -> ServerManagerScreen(repository = repository)
                3 -> PeerManagerScreen(repository = repository)
                4 -> TransactionScreen(repository = repository)
                5 -> PlansAndTrialTab(repository = repository)
                6 -> AnnouncementScreen(repository = repository)
                7 -> AuditAndSettingsTab(authManager = authManager, repository = repository)
            }
        }
    }
}

@Composable
private fun PlansAndTrialTab(repository: AdminRepository) {
    var subTab by remember { mutableIntStateOf(0) }
    androidx.compose.foundation.layout.Column {
        androidx.compose.material3.TabRow(
            selectedTabIndex = subTab,
            containerColor = AdminSurface,
            contentColor = AdminGold
        ) {
            androidx.compose.material3.Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("Pricing Plans", fontWeight = FontWeight.Bold) }
            )
            androidx.compose.material3.Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("Trial & Anti-Fraud", fontWeight = FontWeight.Bold) }
            )
        }
        if (subTab == 0) {
            PremiumPlansScreen(repository = repository)
        } else {
            TrialManagementScreen(repository = repository)
        }
    }
}

@Composable
private fun AuditAndSettingsTab(authManager: AdminAuthManager, repository: AdminRepository) {
    var subTab by remember { mutableIntStateOf(0) }
    androidx.compose.foundation.layout.Column {
        androidx.compose.material3.TabRow(
            selectedTabIndex = subTab,
            containerColor = AdminSurface,
            contentColor = AdminGold
        ) {
            androidx.compose.material3.Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("Audit Trail", fontWeight = FontWeight.Bold) }
            )
            androidx.compose.material3.Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("Settings & Access", fontWeight = FontWeight.Bold) }
            )
        }
        if (subTab == 0) {
            AuditLogScreen(repository = repository)
        } else {
            AdminSettingsScreen(
                authManager = authManager,
                repository = repository,
                onSignOut = {}
            )
        }
    }
}

@Composable
private fun navItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = Color.Black,
    selectedTextColor = AdminGold,
    indicatorColor = AdminGold,
    unselectedIconColor = AdminTextSecondary,
    unselectedTextColor = AdminTextSecondary
)
