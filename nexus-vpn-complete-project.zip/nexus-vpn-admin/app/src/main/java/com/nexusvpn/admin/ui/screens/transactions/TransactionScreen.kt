package com.nexusvpn.admin.ui.screens.transactions

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.nexusvpn.admin.data.AdminRepository
import com.nexusvpn.admin.data.models.QrisTransaction
import com.nexusvpn.admin.ui.theme.AdminBg
import com.nexusvpn.admin.ui.theme.AdminBorder
import com.nexusvpn.admin.ui.theme.AdminCard
import com.nexusvpn.admin.ui.theme.AdminCardElevated
import com.nexusvpn.admin.ui.theme.AdminCyan
import com.nexusvpn.admin.ui.theme.AdminDanger
import com.nexusvpn.admin.ui.theme.AdminGold
import com.nexusvpn.admin.ui.theme.AdminSuccess
import com.nexusvpn.admin.ui.theme.AdminTextPrimary
import com.nexusvpn.admin.ui.theme.AdminTextSecondary
import com.nexusvpn.admin.ui.theme.AdminWarning
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun TransactionScreen(
    repository: AdminRepository,
    modifier: Modifier = Modifier
) {
    val transactions by repository.observeTransactions().collectAsState(initial = emptyList())
    var selectedFilter by remember { mutableIntStateOf(0) } // 0: All, 1: Pending, 2: Paid, 3: Rejected
    var selectedTxForAction by remember { mutableStateOf<QrisTransaction?>(null) }
    val scope = rememberCoroutineScope()

    val filteredList = transactions.filter { tx ->
        when (selectedFilter) {
            1 -> tx.status == "pending"
            2 -> tx.status == "paid"
            3 -> tx.status == "rejected"
            else -> true
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AdminBg)
            .padding(16.dp)
    ) {
        Column {
            Text(
                text = "QRIS TRANSACTIONS AUDITOR",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = AdminTextPrimary
            )
            Text(
                text = "Verify Webhooks & Manual Payment Settlements",
                fontSize = 12.sp,
                color = AdminCyan
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Filter chips
        val filterTitles = listOf(
            "All (${transactions.size})",
            "Pending (${transactions.count { it.status == "pending" }})",
            "Paid (${transactions.count { it.status == "paid" }})",
            "Rejected"
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filterTitles.size) { index ->
                FilterChip(
                    selected = selectedFilter == index,
                    onClick = { selectedFilter = index },
                    label = { Text(filterTitles[index], fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AdminGold,
                        selectedLabelColor = Color.Black,
                        containerColor = AdminCard,
                        labelColor = AdminTextPrimary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = AdminBorder,
                        selectedBorderColor = AdminGold,
                        enabled = true,
                        selected = selectedFilter == index
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No transactions found in this category.", color = AdminTextSecondary, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredList, key = { it.transactionId }) { tx ->
                    TransactionCardItem(
                        tx = tx,
                        onClick = { selectedTxForAction = tx }
                    )
                }
            }
        }
    }

    selectedTxForAction?.let { tx ->
        TransactionActionModal(
            tx = tx,
            onDismiss = { selectedTxForAction = null },
            onVerify = { newStatus, notes ->
                scope.launch {
                    repository.verifyTransaction(tx.transactionId, newStatus, notes)
                    selectedTxForAction = null
                }
            }
        )
    }
}

@Composable
private fun TransactionCardItem(
    tx: QrisTransaction,
    onClick: () -> Unit
) {
    val statusColor = when (tx.status) {
        "paid" -> AdminSuccess
        "pending" -> AdminWarning
        else -> AdminDanger
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AdminCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(statusColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (tx.status) {
                            "paid" -> Icons.Default.CheckCircle
                            "pending" -> Icons.Default.HourglassTop
                            else -> Icons.Default.Close
                        },
                        contentDescription = null,
                        tint = statusColor,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "Rp ${formatRupiah(tx.amount)}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        color = AdminTextPrimary
                    )
                    Text(
                        text = if (tx.userEmail.isNotBlank()) tx.userEmail else "UID: ${tx.userId.take(10)}...",
                        fontSize = 12.sp,
                        color = AdminTextSecondary
                    )
                    Text(
                        text = tx.transactionId,
                        fontSize = 10.sp,
                        color = AdminCyan
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = statusColor.copy(alpha = 0.2f)
            ) {
                Text(
                    text = tx.status.uppercase(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = statusColor,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun TransactionActionModal(
    tx: QrisTransaction,
    onDismiss: () -> Unit,
    onVerify: (newStatus: String, notes: String) -> Unit
) {
    var adminNotes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AdminCardElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Transaction Settlement Action", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = AdminTextPrimary)
                Spacer(modifier = Modifier.height(12.dp))

                DetailRow("Order ID", tx.transactionId)
                DetailRow("Amount", "Rp ${formatRupiah(tx.amount)}")
                DetailRow("Plan", tx.planType.uppercase())
                DetailRow("Target User", tx.userEmail.ifBlank { tx.userId })
                DetailRow("Current Status", tx.status.uppercase())

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = adminNotes,
                    onValueChange = { adminNotes = it },
                    label = { Text("Admin Audit Note / Reference", color = AdminTextSecondary, fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AdminTextPrimary,
                        unfocusedTextColor = AdminTextPrimary,
                        focusedBorderColor = AdminGold,
                        unfocusedBorderColor = AdminBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { onVerify("rejected", adminNotes) },
                        colors = ButtonDefaults.buttonColors(containerColor = AdminDanger, contentColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Reject", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onVerify("paid", adminNotes) },
                        colors = ButtonDefaults.buttonColors(containerColor = AdminSuccess, contentColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Approve PAID", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = AdminTextSecondary)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AdminTextPrimary)
    }
}

private fun formatRupiah(amount: Long): String {
    return String.format("%,d", amount).replace(',', '.')
}
