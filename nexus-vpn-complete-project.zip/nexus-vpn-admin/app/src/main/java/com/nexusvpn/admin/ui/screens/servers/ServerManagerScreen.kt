package com.nexusvpn.admin.ui.screens.servers

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.nexusvpn.admin.data.AdminRepository
import com.nexusvpn.admin.data.models.WireGuardServer
import com.nexusvpn.admin.ui.theme.AdminBg
import com.nexusvpn.admin.ui.theme.AdminBorder
import com.nexusvpn.admin.ui.theme.AdminCard
import com.nexusvpn.admin.ui.theme.AdminCardElevated
import com.nexusvpn.admin.ui.theme.AdminCyan
import com.nexusvpn.admin.ui.theme.AdminDanger
import com.nexusvpn.admin.ui.theme.AdminGold
import com.nexusvpn.admin.ui.theme.AdminSuccess
import com.nexusvpn.admin.ui.theme.AdminTextPrimary
import com.nexusvpn.admin.ui.theme.AdminTextSecondary
import kotlinx.coroutines.launch

@Composable
fun ServerManagerScreen(
    repository: AdminRepository,
    modifier: Modifier = Modifier
) {
    val servers by repository.observeServers().collectAsState(initial = emptyList())
    var editingServer by remember { mutableStateOf<WireGuardServer?>(null) }
    var isCreatingNew by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AdminBg)
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "WIREGUARD SERVER FLEET",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = AdminTextPrimary
                    )
                    Text(
                        text = "${servers.size} Active Node Clusters",
                        fontSize = 12.sp,
                        color = AdminCyan
                    )
                }

                Button(
                    onClick = { isCreatingNew = true },
                    colors = ButtonDefaults.buttonColors(containerColor = AdminGold, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Node", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(servers, key = { it.id }) { server ->
                    ServerCardItem(
                        server = server,
                        onEdit = { editingServer = server },
                        onToggleOnline = { isOnline ->
                            scope.launch {
                                repository.saveServer(server.copy(isOnline = isOnline))
                            }
                        },
                        onDelete = {
                            scope.launch {
                                repository.deleteServer(server.id)
                            }
                        }
                    )
                }
            }
        }

        if (isCreatingNew || editingServer != null) {
            AddEditServerModal(
                server = editingServer ?: WireGuardServer(),
                onDismiss = {
                    isCreatingNew = false
                    editingServer = null
                },
                onSave = { updatedServer ->
                    scope.launch {
                        repository.saveServer(updatedServer)
                        isCreatingNew = false
                        editingServer = null
                    }
                }
            )
        }
    }
}

@Composable
private fun ServerCardItem(
    server: WireGuardServer,
    onEdit: () -> Unit,
    onToggleOnline: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AdminCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = server.flagEmoji.ifBlank { "🌐" }, fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = server.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = AdminTextPrimary
                            )
                            if (server.isPremium) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(shape = RoundedCornerShape(4.dp), color = AdminGold.copy(alpha = 0.2f)) {
                                    Text("VIP", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AdminGold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                }
                            }
                        }
                        Text(
                            text = "${server.host}:${server.port} • ${server.pingMs} ms",
                            fontSize = 12.sp,
                            color = AdminTextSecondary
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = server.isOnline,
                        onCheckedChange = onToggleOnline,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = AdminSuccess,
                            checkedTrackColor = AdminSuccess.copy(alpha = 0.3f),
                            uncheckedThumbColor = AdminDanger,
                            uncheckedTrackColor = AdminDanger.copy(alpha = 0.3f)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Key: ${server.serverPublicKey.take(16)}...",
                    fontSize = 11.sp,
                    color = AdminTextSecondary
                )

                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = AdminCyan, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AdminDanger, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun AddEditServerModal(
    server: WireGuardServer,
    onDismiss: () -> Unit,
    onSave: (WireGuardServer) -> Unit
) {
    var name by remember { mutableStateOf(server.name) }
    var host by remember { mutableStateOf(server.host) }
    var port by remember { mutableStateOf(server.port.toString()) }
    var flagEmoji by remember { mutableStateOf(server.flagEmoji) }
    var countryName by remember { mutableStateOf(server.countryName) }
    var serverPublicKey by remember { mutableStateOf(server.serverPublicKey) }
    var isPremium by remember { mutableStateOf(server.isPremium) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AdminCardElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = if (server.id.isBlank()) "Deploy New WireGuard Node" else "Edit Server Node",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = AdminTextPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))

                AdminField(value = name, onValueChange = { name = it }, label = "Node Name (e.g. Singapore SG01)")
                AdminField(value = host, onValueChange = { host = it }, label = "Host IP / Domain")
                AdminField(value = port, onValueChange = { port = it }, label = "Port (UDP, e.g. 51820)")
                AdminField(value = flagEmoji, onValueChange = { flagEmoji = it }, label = "Flag Emoji (e.g. 🇸🇬)")
                AdminField(value = countryName, onValueChange = { countryName = it }, label = "Country Name")
                AdminField(value = serverPublicKey, onValueChange = { serverPublicKey = it }, label = "Server Public Key (Curve25519)")

                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("VIP Premium Only Node", color = AdminTextPrimary, fontSize = 13.sp)
                    Switch(checked = isPremium, onCheckedChange = { isPremium = it })
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = AdminTextSecondary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            onSave(
                                server.copy(
                                    name = name,
                                    host = host,
                                    port = port.toIntOrNull() ?: 51820,
                                    flagEmoji = flagEmoji,
                                    countryName = countryName,
                                    serverPublicKey = serverPublicKey,
                                    isPremium = isPremium
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AdminGold, contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save Node", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminField(value: String, onValueChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, color = AdminTextSecondary, fontSize = 11.sp) },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = AdminTextPrimary,
            unfocusedTextColor = AdminTextPrimary,
            focusedBorderColor = AdminGold,
            unfocusedBorderColor = AdminBorder
        ),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    )
}
