package com.nexusvpn.admin.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusvpn.admin.auth.AdminAuthManager
import com.nexusvpn.admin.data.AdminRepository
import com.nexusvpn.admin.ui.theme.AdminBg
import com.nexusvpn.admin.ui.theme.AdminBorder
import com.nexusvpn.admin.ui.theme.AdminCard
import com.nexusvpn.admin.ui.theme.AdminCyan
import com.nexusvpn.admin.ui.theme.AdminDanger
import com.nexusvpn.admin.ui.theme.AdminGold
import com.nexusvpn.admin.ui.theme.AdminSuccess
import com.nexusvpn.admin.ui.theme.AdminTextPrimary
import com.nexusvpn.admin.ui.theme.AdminTextSecondary

@Composable
fun AdminSettingsScreen(
    authManager: AdminAuthManager,
    repository: AdminRepository,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentAdmin by authManager.currentAdmin.collectAsState()
    var securityPin by remember { mutableStateOf("7890") }
    var emergencyKillswitch by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AdminBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = "ADMINISTRATIVE CONFIGURATION",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = AdminTextPrimary
            )
            Text(
                text = "Security Keys, Endpoints & Authentication",
                fontSize = 12.sp,
                color = AdminCyan
            )
        }

        // 1. Current Identity Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = AdminCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = AdminGold, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Authenticated Administrator", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = AdminTextPrimary)
                }

                Spacer(modifier = Modifier.height(12.dp))

                DetailRow("Admin Email", currentAdmin?.email ?: "admin@nexusvpn.net")
                DetailRow("UID", currentAdmin?.uid ?: "Unknown")
                DetailRow("Role Authority", "MASTER SYSTEM ADMIN")
                DetailRow("Security Level", "Level 4 (Full Access)")
            }
        }

        // 2. Security PIN
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = AdminCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = AdminCyan, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Quick Lock / Biometric Fallback PIN", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = AdminTextPrimary)
                }
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = securityPin,
                    onValueChange = { securityPin = it },
                    label = { Text("Master 4-Digit Security PIN", color = AdminTextSecondary) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AdminTextPrimary,
                        unfocusedTextColor = AdminTextPrimary,
                        focusedBorderColor = AdminGold,
                        unfocusedBorderColor = AdminBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // 3. Emergency Killswitch
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = AdminCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (emergencyKillswitch) AdminDanger else AdminBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = AdminDanger, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Emergency VPN Kill-Switch", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AdminTextPrimary)
                            Text("Immediately block all incoming tunnel connections", fontSize = 11.sp, color = AdminTextSecondary)
                        }
                    }

                    Switch(
                        checked = emergencyKillswitch,
                        onCheckedChange = { emergencyKillswitch = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = AdminDanger,
                            checkedTrackColor = AdminDanger.copy(alpha = 0.3f)
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Sign Out Button
        Button(
            onClick = {
                authManager.signOutAdmin()
                onSignOut()
            },
            colors = ButtonDefaults.buttonColors(containerColor = AdminDanger.copy(alpha = 0.2f), contentColor = AdminDanger),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Icon(Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("END ADMIN SESSION & SIGN OUT", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = AdminTextSecondary)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AdminTextPrimary)
    }
}
