package com.nexusvpn.admin.ui.screens.plans

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.nexusvpn.admin.data.AdminRepository
import com.nexusvpn.admin.data.models.PremiumPlan
import com.nexusvpn.admin.ui.theme.AdminBg
import com.nexusvpn.admin.ui.theme.AdminBorder
import com.nexusvpn.admin.ui.theme.AdminCard
import com.nexusvpn.admin.ui.theme.AdminCardElevated
import com.nexusvpn.admin.ui.theme.AdminCyan
import com.nexusvpn.admin.ui.theme.AdminGold
import com.nexusvpn.admin.ui.theme.AdminSuccess
import com.nexusvpn.admin.ui.theme.AdminTextPrimary
import com.nexusvpn.admin.ui.theme.AdminTextSecondary
import kotlinx.coroutines.launch

@Composable
fun PremiumPlansScreen(
    repository: AdminRepository,
    modifier: Modifier = Modifier
) {
    val plans by repository.observePlans().collectAsState(initial = emptyList())
    var editingPlan by remember { mutableStateOf<PremiumPlan?>(null) }
    var isCreatingNew by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val defaultPlans = if (plans.isEmpty()) {
        listOf(
            PremiumPlan("vip_1m", "VIP 1 Bulan", 29000, 30, listOf("Semua Server VIP", "Uncapped Speed", "No Ads"), true),
            PremiumPlan("vip_3m", "VIP 3 Bulan", 69000, 90, listOf("Semua Server VIP", "Prioritas Latensi Rendah", "Multi-Device"), true),
            PremiumPlan("vip_1y", "VIP 1 Tahun", 199000, 365, listOf("Akses Penuh Seluruh Dunia", "IP Dedikasi", "Support 24/7"), true)
        )
    } else plans

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AdminBg)
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PREMIUM SUBSCRIPTION PLANS",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = AdminTextPrimary
                    )
                    Text(
                        text = "Manage Pricing, Duration & Features",
                        fontSize = 12.sp,
                        color = AdminCyan
                    )
                }

                Button(
                    onClick = { isCreatingNew = true },
                    colors = ButtonDefaults.buttonColors(containerColor = AdminGold, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Plan", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(defaultPlans, key = { it.planId }) { plan ->
                    PlanCardItem(
                        plan = plan,
                        onEdit = { editingPlan = plan },
                        onToggleActive = { active ->
                            scope.launch {
                                repository.savePlan(plan.copy(isActive = active))
                            }
                        }
                    )
                }
            }
        }

        if (isCreatingNew || editingPlan != null) {
            EditPlanModal(
                plan = editingPlan ?: PremiumPlan(),
                onDismiss = {
                    isCreatingNew = false
                    editingPlan = null
                },
                onSave = { updatedPlan ->
                    scope.launch {
                        repository.savePlan(updatedPlan)
                        isCreatingNew = false
                        editingPlan = null
                    }
                }
            )
        }
    }
}

@Composable
private fun PlanCardItem(
    plan: PremiumPlan,
    onEdit: () -> Unit,
    onToggleActive: (Boolean) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AdminCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = AdminGold, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = plan.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = AdminTextPrimary)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = plan.isActive,
                        onCheckedChange = onToggleActive,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = AdminSuccess,
                            checkedTrackColor = AdminSuccess.copy(alpha = 0.3f)
                        )
                    )
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = AdminCyan, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(verticalAlignment = Alignment.Bottom) {
                Text(text = "Rp ${formatRupiah(plan.price)}", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = AdminGold)
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "/ ${plan.durationDays} hari", fontSize = 12.sp, color = AdminTextSecondary)
            }

            Spacer(modifier = Modifier.height(10.dp))

            plan.features.forEach { feature ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = AdminSuccess, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = feature, fontSize = 12.sp, color = AdminTextSecondary)
                }
            }
        }
    }
}

@Composable
private fun EditPlanModal(
    plan: PremiumPlan,
    onDismiss: () -> Unit,
    onSave: (PremiumPlan) -> Unit
) {
    var name by remember { mutableStateOf(plan.name) }
    var price by remember { mutableStateOf(plan.price.toString()) }
    var durationDays by remember { mutableStateOf(plan.durationDays.toString()) }
    var featuresText by remember { mutableStateOf(plan.features.joinToString("\n")) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AdminCardElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(text = "Edit Subscription Plan", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = AdminTextPrimary)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Plan Name", color = AdminTextSecondary, fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AdminTextPrimary,
                        unfocusedTextColor = AdminTextPrimary,
                        focusedBorderColor = AdminGold,
                        unfocusedBorderColor = AdminBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = price,
                    onValueChange = { price = it },
                    label = { Text("Price (IDR, e.g. 29000)", color = AdminTextSecondary, fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AdminTextPrimary,
                        unfocusedTextColor = AdminTextPrimary,
                        focusedBorderColor = AdminGold,
                        unfocusedBorderColor = AdminBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = durationDays,
                    onValueChange = { durationDays = it },
                    label = { Text("Duration (Days, e.g. 30)", color = AdminTextSecondary, fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AdminTextPrimary,
                        unfocusedTextColor = AdminTextPrimary,
                        focusedBorderColor = AdminGold,
                        unfocusedBorderColor = AdminBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = featuresText,
                    onValueChange = { featuresText = it },
                    label = { Text("Features (1 line per feature)", color = AdminTextSecondary, fontSize = 11.sp) },
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AdminTextPrimary,
                        unfocusedTextColor = AdminTextPrimary,
                        focusedBorderColor = AdminGold,
                        unfocusedBorderColor = AdminBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = AdminTextSecondary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val featuresList = featuresText.split("\n").map { it.trim() }.filter { it.isNotBlank() }
                            onSave(
                                plan.copy(
                                    name = name,
                                    price = price.toLongOrNull() ?: 29000L,
                                    durationDays = durationDays.toIntOrNull() ?: 30,
                                    features = featuresList
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AdminGold, contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save Plan", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun formatRupiah(amount: Long): String {
    return String.format("%,d", amount).replace(',', '.')
}
