package com.nexusvpn.admin.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusvpn.admin.data.AdminRepository
import com.nexusvpn.admin.data.models.ServerTelemetry
import com.nexusvpn.admin.ui.theme.AdminBorder
import com.nexusvpn.admin.ui.theme.AdminCard
import com.nexusvpn.admin.ui.theme.AdminCardElevated
import com.nexusvpn.admin.ui.theme.AdminCyan
import com.nexusvpn.admin.ui.theme.AdminDanger
import com.nexusvpn.admin.ui.theme.AdminGold
import com.nexusvpn.admin.ui.theme.AdminRoyalBlue
import com.nexusvpn.admin.ui.theme.AdminSuccess
import com.nexusvpn.admin.ui.theme.AdminTextPrimary
import com.nexusvpn.admin.ui.theme.AdminTextSecondary
import com.nexusvpn.admin.ui.theme.AdminWarning
import kotlinx.coroutines.launch

@Composable
fun AdminDashboardScreen(
    repository: AdminRepository,
    onNavigateToUsers: () -> Unit,
    onNavigateToServers: () -> Unit,
    onNavigateToTransactions: () -> Unit,
    onNavigateToAnnouncements: () -> Unit,
    onNavigateToAudit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val telemetry by repository.observeTelemetry().collectAsState(initial = ServerTelemetry())
    val servers by repository.observeServers().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header Banner
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = AdminCardElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(AdminSuccess)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "CORE SYSTEM ONLINE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AdminSuccess,
                                letterSpacing = 1.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Executive Telemetry",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = AdminTextPrimary
                        )
                        Text(
                            text = "WireGuard Tunnel Mesh & Cloud Control",
                            fontSize = 12.sp,
                            color = AdminTextSecondary
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AdminGold.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AdminGold)
                    ) {
                        Text(
                            text = "PROD v1.0",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AdminGold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // 2. Metrics Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "Total Users",
                        value = "${telemetry.totalUsers}",
                        subtitle = "Registered & Guests",
                        icon = Icons.Default.People,
                        accentColor = AdminCyan,
                        onClick = onNavigateToUsers,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Active Sessions",
                        value = "${telemetry.activeVpnSessions}",
                        subtitle = "Connected Peers",
                        icon = Icons.Default.VpnKey,
                        accentColor = AdminSuccess,
                        onClick = onNavigateToServers,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "Gross Revenue",
                        value = "Rp ${formatRupiah(telemetry.totalRevenue)}",
                        subtitle = "Verified Payments",
                        icon = Icons.Default.MonetizationOn,
                        accentColor = AdminGold,
                        onClick = onNavigateToTransactions,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Pending QRIS",
                        value = "${telemetry.pendingTransactions}",
                        subtitle = if (telemetry.pendingTransactions > 0) "Needs Verification" else "All Cleared",
                        icon = Icons.Default.Warning,
                        accentColor = if (telemetry.pendingTransactions > 0) AdminWarning else AdminTextSecondary,
                        onClick = onNavigateToTransactions,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 3. Hardware / Node Resource Utilization
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = AdminCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "VIRTUAL NETWORK CLUSTER HEALTH",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AdminCyan
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Mesh CPU Load", fontSize = 13.sp, color = AdminTextPrimary)
                        Text("${telemetry.cpuLoadPercent}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdminSuccess)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { telemetry.cpuLoadPercent / 100f },
                        color = AdminSuccess,
                        trackColor = AdminBorder,
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Tunnel Buffer Memory", fontSize = 13.sp, color = AdminTextPrimary)
                        Text("${telemetry.ramLoadPercent}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AdminCyan)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { telemetry.ramLoadPercent / 100f },
                        color = AdminCyan,
                        trackColor = AdminBorder,
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                    )
                }
            }
        }

        // 4. Quick Actions
        item {
            Text(
                text = "MANAGEMENT SHORTCUTS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = AdminTextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionButton(
                    icon = Icons.Default.Dns,
                    label = "Nodes",
                    onClick = onNavigateToServers,
                    modifier = Modifier.weight(1f)
                )
                QuickActionButton(
                    icon = Icons.Default.Campaign,
                    label = "Broadcast",
                    onClick = onNavigateToAnnouncements,
                    modifier = Modifier.weight(1f)
                )
                QuickActionButton(
                    icon = Icons.Default.History,
                    label = "Audit",
                    onClick = onNavigateToAudit,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AdminCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 12.sp, color = AdminTextSecondary)
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = AdminTextPrimary)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 11.sp, color = AdminTextSecondary)
        }
    }
}

@Composable
private fun QuickActionButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AdminCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
        modifier = modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = AdminGold, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AdminTextPrimary)
        }
    }
}

private fun formatRupiah(amount: Long): String {
    return String.format("%,d", amount).replace(',', '.')
}
