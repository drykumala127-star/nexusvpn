package com.nexusvpn.admin.data.models

import com.google.firebase.Timestamp

data class AdminUser(
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val role: String = "user", // "user" or "admin"
    val isGuest: Boolean = false,
    val isTrialUsed: Boolean = false,
    val trialExpiresAt: Timestamp? = null,
    val subscriptionPlan: String = "free", // "free" or "premium"
    val subscriptionExpiresAt: Timestamp? = null,
    val isBanned: Boolean = false,
    val createdAt: Timestamp? = null
)

data class WireGuardServer(
    val id: String = "",
    val name: String = "",
    val countryCode: String = "SG",
    val countryName: String = "Singapore",
    val flagEmoji: String = "🇸🇬",
    val host: String = "",
    val port: Int = 51820,
    val serverPublicKey: String = "",
    val isPremium: Boolean = false,
    val isOnline: Boolean = true,
    val pingMs: Int = 20,
    val loadPercentage: Int = 10
)

data class WireGuardPeer(
    val peerId: String = "",
    val userId: String = "",
    val serverId: String = "",
    val clientPublicKey: String = "",
    val assignedIp: String = "10.66.0.2/32",
    val status: String = "active", // "active" or "revoked"
    val createdAt: Timestamp? = null
)

data class QrisTransaction(
    val transactionId: String = "",
    val userId: String = "",
    val userEmail: String = "",
    val planType: String = "",
    val amount: Long = 0L,
    val status: String = "pending", // "pending", "paid", "rejected"
    val planDurationDays: Int = 30,
    val adminNotes: String = "",
    val verifiedByAdmin: String = "",
    val createdAt: Timestamp? = null,
    val paidAt: Timestamp? = null
)

data class PremiumPlan(
    val planId: String = "",
    val name: String = "",
    val price: Long = 0L,
    val durationDays: Int = 30,
    val features: List<String> = emptyList(),
    val isActive: Boolean = true
)

data class Announcement(
    val id: String = "",
    val title: String = "",
    val message: String = "",
    val priority: String = "normal", // "low", "normal", "urgent"
    val targetAudience: String = "all", // "all", "premium", "free"
    val isActive: Boolean = true,
    val createdBy: String = "",
    val createdAt: Timestamp? = null
)

data class AuditLog(
    val id: String = "",
    val adminUid: String = "",
    val adminEmail: String = "",
    val action: String = "",
    val target: String = "",
    val details: String = "",
    val timestamp: Timestamp? = null
)

data class ServerTelemetry(
    val totalUsers: Int = 0,
    val activeVpnSessions: Int = 0,
    val totalRevenue: Long = 0L,
    val activeServers: Int = 0,
    val pendingTransactions: Int = 0,
    val activePeers: Int = 0,
    val cpuLoadPercent: Int = 14,
    val ramLoadPercent: Int = 38
)

data class TrialConfig(
    val trialHours: Int = 24,
    val isTrialEnabled: Boolean = true,
    val maxClaimsPerDevice: Int = 1
)
