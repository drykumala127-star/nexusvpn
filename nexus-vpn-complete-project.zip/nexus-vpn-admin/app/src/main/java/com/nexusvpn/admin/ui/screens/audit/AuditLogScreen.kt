package com.nexusvpn.admin.ui.screens.audit

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusvpn.admin.data.AdminRepository
import com.nexusvpn.admin.data.models.AuditLog
import com.nexusvpn.admin.ui.theme.AdminBg
import com.nexusvpn.admin.ui.theme.AdminBorder
import com.nexusvpn.admin.ui.theme.AdminCard
import com.nexusvpn.admin.ui.theme.AdminCyan
import com.nexusvpn.admin.ui.theme.AdminGold
import com.nexusvpn.admin.ui.theme.AdminSuccess
import com.nexusvpn.admin.ui.theme.AdminTextPrimary
import com.nexusvpn.admin.ui.theme.AdminTextSecondary
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun AuditLogScreen(
    repository: AdminRepository,
    modifier: Modifier = Modifier
) {
    val auditLogs by repository.observeAuditLogs().collectAsState(initial = emptyList())

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AdminBg)
            .padding(16.dp)
    ) {
        Column {
            Text(
                text = "IMMUTABLE AUDIT LOG LEDGER",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = AdminTextPrimary
            )
            Text(
                text = "Tamper-Proof Administrative Event History",
                fontSize = 12.sp,
                color = AdminCyan
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (auditLogs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No audit log records recorded yet.", color = AdminTextSecondary, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(auditLogs, key = { it.id }) { log ->
                    AuditLogItem(log = log)
                }
            }
        }
    }
}

@Composable
private fun AuditLogItem(log: AuditLog) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AdminCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(AdminGold.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = AdminGold,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = log.action,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = AdminTextPrimary
                    )
                }

                log.timestamp?.let {
                    val date = SimpleDateFormat("dd MMM, HH:mm:ss", Locale.getDefault()).format(it.toDate())
                    Text(text = date, fontSize = 11.sp, color = AdminTextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Target: ${log.target}",
                fontSize = 11.sp,
                color = AdminCyan,
                fontWeight = FontWeight.Medium
            )

            if (log.details.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = log.details,
                    fontSize = 12.sp,
                    color = AdminTextSecondary,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "By: ${log.adminEmail}",
                fontSize = 10.sp,
                color = AdminTextSecondary
            )
        }
    }
}
