package com.nexusvpn.admin.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val AdminDarkColorScheme = darkColorScheme(
    primary = AdminGold,
    onPrimary = AdminBg,
    primaryContainer = AdminCard,
    onPrimaryContainer = AdminGold,
    secondary = AdminCyan,
    onSecondary = AdminBg,
    background = AdminBg,
    onBackground = AdminTextPrimary,
    surface = AdminSurface,
    onSurface = AdminTextPrimary,
    surfaceVariant = AdminCard,
    onSurfaceVariant = AdminTextSecondary,
    outline = AdminBorder
)

@Composable
fun NexusAdminTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = AdminDarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = AdminSurface.toArgb()
            window.navigationBarColor = AdminBg.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
