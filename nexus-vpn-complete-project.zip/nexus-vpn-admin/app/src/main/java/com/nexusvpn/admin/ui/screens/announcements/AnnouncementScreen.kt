package com.nexusvpn.admin.ui.screens.announcements

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.nexusvpn.admin.data.AdminRepository
import com.nexusvpn.admin.data.models.Announcement
import com.nexusvpn.admin.ui.theme.AdminBg
import com.nexusvpn.admin.ui.theme.AdminBorder
import com.nexusvpn.admin.ui.theme.AdminCard
import com.nexusvpn.admin.ui.theme.AdminCardElevated
import com.nexusvpn.admin.ui.theme.AdminCyan
import com.nexusvpn.admin.ui.theme.AdminDanger
import com.nexusvpn.admin.ui.theme.AdminGold
import com.nexusvpn.admin.ui.theme.AdminSuccess
import com.nexusvpn.admin.ui.theme.AdminTextPrimary
import com.nexusvpn.admin.ui.theme.AdminTextSecondary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun AnnouncementScreen(
    repository: AdminRepository,
    modifier: Modifier = Modifier
) {
    val announcements by repository.observeAnnouncements().collectAsState(initial = emptyList())
    var isCreatingAnnouncement by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AdminBg)
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SYSTEM ANNOUNCEMENTS & FCM",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = AdminTextPrimary
                    )
                    Text(
                        text = "Global Broadcast & Target VIP Push",
                        fontSize = 12.sp,
                        color = AdminCyan
                    )
                }

                Button(
                    onClick = { isCreatingAnnouncement = true },
                    colors = ButtonDefaults.buttonColors(containerColor = AdminGold, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Broadcast", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (announcements.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No announcements published yet.", color = AdminTextSecondary, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(announcements, key = { it.id }) { item ->
                        AnnouncementCardItem(item = item)
                    }
                }
            }
        }

        if (isCreatingAnnouncement) {
            BroadcastModal(
                onDismiss = { isCreatingAnnouncement = false },
                onSend = { title, message, priority, audience, _ ->
                    scope.launch {
                        repository.broadcastAnnouncement(title, message, priority, audience)
                        isCreatingAnnouncement = false
                    }
                }
            )
        }
    }
}

@Composable
private fun AnnouncementCardItem(item: Announcement) {
    val priorityColor = when (item.priority) {
        "urgent" -> AdminDanger
        "low" -> AdminTextSecondary
        else -> AdminGold
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AdminCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = AdminTextPrimary,
                    modifier = Modifier.weight(1f)
                )

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = priorityColor.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = item.priority.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = priorityColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = item.message,
                fontSize = 12.sp,
                color = AdminTextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Audience: ${item.targetAudience.uppercase()}",
                    fontSize = 10.sp,
                    color = AdminCyan
                )

                item.createdAt?.let {
                    val date = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(it.toDate())
                    Text(text = date, fontSize = 10.sp, color = AdminTextSecondary)
                }
            }
        }
    }
}

@Composable
private fun BroadcastModal(
    onDismiss: () -> Unit,
    onSend: (title: String, message: String, priority: String, audience: String, sendPush: Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("normal") }
    var audience by remember { mutableStateOf("all") }
    var sendPush by remember { mutableStateOf(true) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AdminCardElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Broadcast System Announcement", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = AdminTextPrimary)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Announcement Headline", color = AdminTextSecondary, fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AdminTextPrimary,
                        unfocusedTextColor = AdminTextPrimary,
                        focusedBorderColor = AdminGold,
                        unfocusedBorderColor = AdminBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("Detailed Message Body", color = AdminTextSecondary, fontSize = 11.sp) },
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AdminTextPrimary,
                        unfocusedTextColor = AdminTextPrimary,
                        focusedBorderColor = AdminGold,
                        unfocusedBorderColor = AdminBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = sendPush,
                        onCheckedChange = { sendPush = it },
                        colors = CheckboxDefaults.colors(checkedColor = AdminGold)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Trigger Firebase Cloud Messaging Push Notification", fontSize = 11.sp, color = AdminTextPrimary)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = AdminTextSecondary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            if (title.isNotBlank() && message.isNotBlank()) {
                                onSend(title, message, priority, audience, sendPush)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AdminGold, contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Send Now", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
