package com.nexusvpn.admin.ui.screens.peers

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusvpn.admin.data.AdminRepository
import com.nexusvpn.admin.data.models.WireGuardPeer
import com.nexusvpn.admin.ui.theme.AdminBg
import com.nexusvpn.admin.ui.theme.AdminBorder
import com.nexusvpn.admin.ui.theme.AdminCard
import com.nexusvpn.admin.ui.theme.AdminCyan
import com.nexusvpn.admin.ui.theme.AdminDanger
import com.nexusvpn.admin.ui.theme.AdminGold
import com.nexusvpn.admin.ui.theme.AdminSuccess
import com.nexusvpn.admin.ui.theme.AdminTextPrimary
import com.nexusvpn.admin.ui.theme.AdminTextSecondary
import kotlinx.coroutines.launch

@Composable
fun PeerManagerScreen(
    repository: AdminRepository,
    modifier: Modifier = Modifier
) {
    val peers by repository.observePeers().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AdminBg)
            .padding(16.dp)
    ) {
        Text(
            text = "WIREGUARD ACTIVE PEERS",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = AdminTextPrimary
        )
        Text(
            text = "${peers.count { it.status == "active" }} Active Mesh Connections",
            fontSize = 12.sp,
            color = AdminCyan
        )

        Spacer(modifier = Modifier.height(14.dp))

        if (peers.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No active peers provisioned yet.", color = AdminTextSecondary, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(peers, key = { it.peerId }) { peer ->
                    PeerCardItem(
                        peer = peer,
                        onRevoke = {
                            scope.launch {
                                repository.revokePeer(peer.peerId)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun PeerCardItem(
    peer: WireGuardPeer,
    onRevoke: () -> Unit
) {
    val isActive = peer.status == "active"

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AdminCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isActive) AdminSuccess.copy(alpha = 0.2f) else AdminDanger.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VpnKey,
                            contentDescription = null,
                            tint = if (isActive) AdminSuccess else AdminDanger,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = "IP: ${peer.assignedIp}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = AdminTextPrimary
                        )
                        Text(
                            text = "UID: ${peer.userId.take(12)}...",
                            fontSize = 12.sp,
                            color = AdminTextSecondary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isActive) AdminSuccess.copy(alpha = 0.2f) else AdminDanger.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = peer.status.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isActive) AdminSuccess else AdminDanger,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Public Key: ${peer.clientPublicKey}",
                fontSize = 11.sp,
                color = AdminTextSecondary
            )

            if (isActive) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onRevoke,
                    colors = ButtonDefaults.buttonColors(containerColor = AdminDanger.copy(alpha = 0.2f), contentColor = AdminDanger),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Revoke Tunnel Key & Free IP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
