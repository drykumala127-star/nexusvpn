package com.nexusvpn.admin.data

import android.util.Log
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.nexusvpn.admin.data.models.AdminUser
import com.nexusvpn.admin.data.models.Announcement
import com.nexusvpn.admin.data.models.AuditLog
import com.nexusvpn.admin.data.models.PremiumPlan
import com.nexusvpn.admin.data.models.QrisTransaction
import com.nexusvpn.admin.data.models.ServerTelemetry
import com.nexusvpn.admin.data.models.TrialConfig
import com.nexusvpn.admin.data.models.WireGuardPeer
import com.nexusvpn.admin.data.models.WireGuardServer
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class AdminRepository {

    companion object {
        private const val TAG = "AdminRepository"
    }

    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    private fun getCurrentAdminEmail(): String {
        return auth.currentUser?.email ?: "admin@nexusvpn.net"
    }

    private fun getCurrentAdminUid(): String {
        return auth.currentUser?.uid ?: "admin_uid"
    }

    // 1. Audit Logging Otomatis untuk Setiap Tindakan Admin
    suspend fun recordAuditLog(action: String, target: String, details: String) {
        try {
            db.collection("audit_logs").add(
                mapOf(
                    "adminUid" to getCurrentAdminUid(),
                    "adminEmail" to getCurrentAdminEmail(),
                    "action" to action,
                    "target" to target,
                    "details" to details,
                    "timestamp" to Timestamp.now()
                )
            ).await()
        } catch (e: Exception) {
            Log.w(TAG, "Gagal mencatat audit log: ${e.message}")
        }
    }

    // 2. Real-Time Telemetry Dashboard
    fun observeTelemetry(): Flow<ServerTelemetry> = callbackFlow {
        val listener = db.collection("users").addSnapshotListener { usersSnap, _ ->
            val totalUsers = usersSnap?.size() ?: 0

            db.collection("servers").get().addOnSuccessListener { serversSnap ->
                val activeServers = serversSnap.documents.count { it.getBoolean("isOnline") == true }

                db.collection("qris_transactions").get().addOnSuccessListener { txSnap ->
                    var revenue = 0L
                    var pendingCount = 0
                    txSnap.documents.forEach { doc ->
                        if (doc.getString("status") == "paid") {
                            revenue += doc.getLong("amount") ?: 0L
                        } else if (doc.getString("status") == "pending") {
                            pendingCount++
                        }
                    }

                    db.collection("wireguard_peers").get().addOnSuccessListener { peerSnap ->
                        val activePeers = peerSnap.documents.count { it.getString("status") == "active" }

                        trySend(
                            ServerTelemetry(
                                totalUsers = totalUsers,
                                activeVpnSessions = activePeers,
                                totalRevenue = revenue,
                                activeServers = activeServers,
                                pendingTransactions = pendingCount,
                                activePeers = activePeers,
                                cpuLoadPercent = (12..28).random(),
                                ramLoadPercent = (35..45).random()
                            )
                        )
                    }
                }
            }
        }
        awaitClose { listener.remove() }
    }

    // 3. User Management
    fun observeUsers(): Flow<List<AdminUser>> = callbackFlow {
        val listener = db.collection("users")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    Log.w(TAG, "observeUsers error: ${error.message}")
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { doc ->
                    AdminUser(
                        uid = doc.id,
                        email = doc.getString("email") ?: "",
                        displayName = doc.getString("displayName") ?: "User",
                        role = doc.getString("role") ?: "user",
                        isGuest = doc.getBoolean("isGuest") ?: false,
                        isTrialUsed = doc.getBoolean("isTrialUsed") ?: false,
                        trialExpiresAt = doc.getTimestamp("trialExpiresAt"),
                        subscriptionPlan = doc.getString("subscriptionPlan") ?: "free",
                        subscriptionExpiresAt = doc.getTimestamp("subscriptionExpiresAt"),
                        isBanned = doc.getBoolean("isBanned") ?: false,
                        createdAt = doc.getTimestamp("createdAt")
                    )
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun updateUser(
        uid: String,
        plan: String,
        durationDays: Int,
        isBanned: Boolean,
        resetTrial: Boolean
    ): Result<Unit> {
        return try {
            val userRef = db.collection("users").document(uid)
            val updates = mutableMapOf<String, Any>(
                "subscriptionPlan" to plan,
                "isBanned" to isBanned,
                "updatedAt" to Timestamp.now()
            )
            if (plan == "premium") {
                val expiresAt = Timestamp(Timestamp.now().seconds + durationDays * 86400L, 0)
                updates["subscriptionExpiresAt"] = expiresAt
            } else {
                updates["subscriptionExpiresAt"] = com.google.firebase.firestore.FieldValue.delete()
            }
            if (resetTrial) {
                updates["isTrialUsed"] = false
                updates["trialExpiresAt"] = com.google.firebase.firestore.FieldValue.delete()
            }

            userRef.update(updates).await()

            recordAuditLog(
                action = "UPDATE_USER_STATUS",
                target = uid,
                details = "Plan: $plan, Banned: $isBanned, ResetTrial: $resetTrial"
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 4. WireGuard Servers Fleet
    fun observeServers(): Flow<List<WireGuardServer>> = callbackFlow {
        val listener = db.collection("servers").addSnapshotListener { snap, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snap?.documents?.mapNotNull { doc ->
                WireGuardServer(
                    id = doc.id,
                    name = doc.getString("name") ?: "",
                    countryCode = doc.getString("countryCode") ?: "SG",
                    countryName = doc.getString("countryName") ?: "Singapore",
                    flagEmoji = doc.getString("flagEmoji") ?: "🌐",
                    host = doc.getString("host") ?: "",
                    port = (doc.getLong("port") ?: 51820).toInt(),
                    serverPublicKey = doc.getString("serverPublicKey") ?: "",
                    isPremium = doc.getBoolean("isPremium") ?: false,
                    isOnline = doc.getBoolean("isOnline") ?: true,
                    pingMs = (doc.getLong("pingMs") ?: 20).toInt(),
                    loadPercentage = (doc.getLong("loadPercentage") ?: 10).toInt()
                )
            } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    suspend fun saveServer(server: WireGuardServer): Result<Unit> {
        return try {
            val docId = if (server.id.isBlank()) "srv_${System.currentTimeMillis()}" else server.id
            db.collection("servers").document(docId).set(
                mapOf(
                    "id" to docId,
                    "name" to server.name,
                    "countryCode" to server.countryCode,
                    "countryName" to server.countryName,
                    "flagEmoji" to server.flagEmoji,
                    "host" to server.host,
                    "port" to server.port,
                    "serverPublicKey" to server.serverPublicKey,
                    "isPremium" to server.isPremium,
                    "isOnline" to server.isOnline,
                    "pingMs" to server.pingMs,
                    "loadPercentage" to server.loadPercentage,
                    "updatedAt" to Timestamp.now()
                )
            ).await()

            recordAuditLog("SAVE_SERVER", docId, "Node: ${server.name} (${server.host}:${server.port})")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteServer(serverId: String): Result<Unit> {
        return try {
            db.collection("servers").document(serverId).delete().await()
            recordAuditLog("DELETE_SERVER", serverId, "Deleted WireGuard node")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 5. WireGuard Peers
    fun observePeers(): Flow<List<WireGuardPeer>> = callbackFlow {
        val listener = db.collection("wireguard_peers")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.mapNotNull { doc ->
                    WireGuardPeer(
                        peerId = doc.id,
                        userId = doc.getString("userId") ?: "",
                        serverId = doc.getString("serverId") ?: "",
                        clientPublicKey = doc.getString("clientPublicKey") ?: "",
                        assignedIp = doc.getString("assignedIp") ?: "10.66.0.2/32",
                        status = doc.getString("status") ?: "active",
                        createdAt = doc.getTimestamp("createdAt")
                    )
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun revokePeer(peerId: String): Result<Unit> {
        return try {
            db.collection("wireguard_peers").document(peerId).update(
                mapOf(
                    "status" to "revoked",
                    "revokedAt" to Timestamp.now(),
                    "revokedBy" to getCurrentAdminEmail()
                )
            ).await()

            recordAuditLog("REVOKE_PEER", peerId, "Peer revoked from mesh")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 6. QRIS Transactions
    fun observeTransactions(): Flow<List<QrisTransaction>> = callbackFlow {
        val listener = db.collection("qris_transactions")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.mapNotNull { doc ->
                    QrisTransaction(
                        transactionId = doc.id,
                        userId = doc.getString("userId") ?: "",
                        userEmail = doc.getString("userEmail") ?: "",
                        planType = doc.getString("planType") ?: "vip",
                        amount = doc.getLong("amount") ?: 0L,
                        status = doc.getString("status") ?: "pending",
                        planDurationDays = (doc.getLong("planDurationDays") ?: 30).toInt(),
                        adminNotes = doc.getString("adminNotes") ?: "",
                        verifiedByAdmin = doc.getString("verifiedByAdmin") ?: "",
                        createdAt = doc.getTimestamp("createdAt"),
                        paidAt = doc.getTimestamp("paidAt")
                    )
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun verifyTransaction(
        transactionId: String,
        newStatus: String,
        notes: String
    ): Result<Unit> {
        return try {
            val txRef = db.collection("qris_transactions").document(transactionId)
            val txDoc = txRef.get().await()
            val userId = txDoc.getString("userId") ?: ""
            val durationDays = (txDoc.getLong("planDurationDays") ?: 30).toInt()

            val updates = mutableMapOf<String, Any>(
                "status" to newStatus,
                "verifiedByAdmin" to getCurrentAdminEmail(),
                "adminNotes" to notes,
                "updatedAt" to Timestamp.now()
            )
            if (newStatus == "paid") {
                updates["paidAt"] = Timestamp.now()
            }
            txRef.update(updates).await()

            // Jika status disetujui PAID, otomatis upgrade akun user menjadi Premium
            if (newStatus == "paid" && userId.isNotBlank()) {
                val expiresAt = Timestamp(Timestamp.now().seconds + durationDays * 86400L, 0)
                db.collection("users").document(userId).update(
                    mapOf(
                        "subscriptionPlan" to "premium",
                        "subscriptionExpiresAt" to expiresAt,
                        "updatedAt" to Timestamp.now()
                    )
                ).await()
            }

            recordAuditLog(
                action = "VERIFY_TRANSACTION_$newStatus",
                target = transactionId,
                details = "Admin marked $newStatus. Notes: $notes"
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 7. Premium Plans
    fun observePlans(): Flow<List<PremiumPlan>> = callbackFlow {
        val listener = db.collection("premium_plans").addSnapshotListener { snap, _ ->
            val list = snap?.documents?.mapNotNull { doc ->
                @Suppress("UNCHECKED_CAST")
                PremiumPlan(
                    planId = doc.id,
                    name = doc.getString("name") ?: "",
                    price = doc.getLong("price") ?: 0L,
                    durationDays = (doc.getLong("durationDays") ?: 30).toInt(),
                    features = (doc.get("features") as? List<String>) ?: emptyList(),
                    isActive = doc.getBoolean("isActive") ?: true
                )
            } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    suspend fun savePlan(plan: PremiumPlan): Result<Unit> {
        return try {
            val id = if (plan.planId.isBlank()) "plan_${System.currentTimeMillis()}" else plan.planId
            db.collection("premium_plans").document(id).set(
                mapOf(
                    "planId" to id,
                    "name" to plan.name,
                    "price" to plan.price,
                    "durationDays" to plan.durationDays,
                    "features" to plan.features,
                    "isActive" to plan.isActive,
                    "updatedAt" to Timestamp.now()
                )
            ).await()

            recordAuditLog("SAVE_PLAN", id, "Plan ${plan.name} (Rp ${plan.price})")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 8. Trial Settings
    fun observeTrialConfig(): Flow<TrialConfig> = callbackFlow {
        val listener = db.collection("app_settings").document("trial_config")
            .addSnapshotListener { doc, _ ->
                if (doc != null && doc.exists()) {
                    trySend(
                        TrialConfig(
                            trialHours = (doc.getLong("trialHours") ?: 24).toInt(),
                            isTrialEnabled = doc.getBoolean("isTrialEnabled") ?: true,
                            maxClaimsPerDevice = (doc.getLong("maxClaimsPerDevice") ?: 1).toInt()
                        )
                    )
                } else {
                    trySend(TrialConfig())
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun saveTrialConfig(config: TrialConfig): Result<Unit> {
        return try {
            db.collection("app_settings").document("trial_config").set(
                mapOf(
                    "trialHours" to config.trialHours,
                    "isTrialEnabled" to config.isTrialEnabled,
                    "maxClaimsPerDevice" to config.maxClaimsPerDevice,
                    "updatedBy" to getCurrentAdminEmail(),
                    "updatedAt" to Timestamp.now()
                )
            ).await()

            recordAuditLog("UPDATE_TRIAL_SETTINGS", "trial_config", "Hours: ${config.trialHours}, Enabled: ${config.isTrialEnabled}")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 9. Announcements & FCM Push
    fun observeAnnouncements(): Flow<List<Announcement>> = callbackFlow {
        val listener = db.collection("announcements")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(50)
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.mapNotNull { doc ->
                    Announcement(
                        id = doc.id,
                        title = doc.getString("title") ?: "",
                        message = doc.getString("message") ?: "",
                        priority = doc.getString("priority") ?: "normal",
                        targetAudience = doc.getString("targetAudience") ?: "all",
                        isActive = doc.getBoolean("isActive") ?: true,
                        createdBy = doc.getString("createdBy") ?: "",
                        createdAt = doc.getTimestamp("createdAt")
                    )
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun broadcastAnnouncement(
        title: String,
        message: String,
        priority: String,
        targetAudience: String
    ): Result<Unit> {
        return try {
            val docRef = db.collection("announcements").add(
                mapOf(
                    "title" to title,
                    "message" to message,
                    "priority" to priority,
                    "targetAudience" to targetAudience,
                    "isActive" to true,
                    "createdBy" to getCurrentAdminEmail(),
                    "createdAt" to Timestamp.now()
                )
            ).await()

            recordAuditLog("BROADCAST_ANNOUNCEMENT", docRef.id, "Title: $title (Target: $targetAudience)")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 10. Immutable Audit Logs
    fun observeAuditLogs(): Flow<List<AuditLog>> = callbackFlow {
        val listener = db.collection("audit_logs")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .limit(150)
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.mapNotNull { doc ->
                    AuditLog(
                        id = doc.id,
                        adminUid = doc.getString("adminUid") ?: "",
                        adminEmail = doc.getString("adminEmail") ?: "",
                        action = doc.getString("action") ?: "",
                        target = doc.getString("target") ?: "",
                        details = doc.getString("details") ?: "",
                        timestamp = doc.getTimestamp("timestamp")
                    )
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }
}
