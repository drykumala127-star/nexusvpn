package com.nexusvpn.admin.ui.screens.users

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.nexusvpn.admin.data.AdminRepository
import com.nexusvpn.admin.data.models.AdminUser
import com.nexusvpn.admin.ui.theme.AdminBg
import com.nexusvpn.admin.ui.theme.AdminBorder
import com.nexusvpn.admin.ui.theme.AdminCard
import com.nexusvpn.admin.ui.theme.AdminCardElevated
import com.nexusvpn.admin.ui.theme.AdminCyan
import com.nexusvpn.admin.ui.theme.AdminDanger
import com.nexusvpn.admin.ui.theme.AdminGold
import com.nexusvpn.admin.ui.theme.AdminSuccess
import com.nexusvpn.admin.ui.theme.AdminTextPrimary
import com.nexusvpn.admin.ui.theme.AdminTextSecondary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun UserListScreen(
    repository: AdminRepository,
    modifier: Modifier = Modifier
) {
    val users by repository.observeUsers().collectAsState(initial = emptyList())
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableIntStateOf(0) } // 0: All, 1: VIP, 2: Free, 3: Guest, 4: Banned
    var selectedUserForDetail by remember { mutableStateOf<AdminUser?>(null) }
    val scope = rememberCoroutineScope()

    val filteredUsers = users.filter { user ->
        val matchesQuery = searchQuery.isBlank() ||
                user.email.contains(searchQuery, ignoreCase = true) ||
                user.displayName.contains(searchQuery, ignoreCase = true) ||
                user.uid.contains(searchQuery, ignoreCase = true)

        val matchesFilter = when (selectedFilter) {
            1 -> user.subscriptionPlan == "premium"
            2 -> user.subscriptionPlan == "free"
            3 -> user.isGuest
            4 -> user.isBanned
            else -> true
        }

        matchesQuery && matchesFilter
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AdminBg)
            .padding(16.dp)
    ) {
        // Search field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by email, name, or UID...", color = AdminTextSecondary, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AdminCyan) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = AdminTextSecondary)
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = AdminTextPrimary,
                unfocusedTextColor = AdminTextPrimary,
                focusedBorderColor = AdminGold,
                unfocusedBorderColor = AdminBorder
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filter chips
        val filters = listOf("All (${users.size})", "VIP (${users.count { it.subscriptionPlan == "premium" }})", "Free", "Guests", "Banned")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filters.size) { index ->
                FilterChip(
                    selected = selectedFilter == index,
                    onClick = { selectedFilter = index },
                    label = { Text(filters[index], fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AdminGold,
                        selectedLabelColor = Color.Black,
                        containerColor = AdminCard,
                        labelColor = AdminTextPrimary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = AdminBorder,
                        selectedBorderColor = AdminGold,
                        enabled = true,
                        selected = selectedFilter == index
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Users List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredUsers, key = { it.uid }) { user ->
                UserItemCard(
                    user = user,
                    onClick = { selectedUserForDetail = user }
                )
            }
        }
    }

    // User Detail & Action Dialog
    selectedUserForDetail?.let { user ->
        UserDetailModal(
            user = user,
            onDismiss = { selectedUserForDetail = null },
            onUpdate = { plan, duration, banned, resetTrial ->
                scope.launch {
                    repository.updateUser(user.uid, plan, duration, banned, resetTrial)
                    selectedUserForDetail = null
                }
            }
        )
    }
}

@Composable
private fun UserItemCard(
    user: AdminUser,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AdminCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            if (user.isBanned) AdminDanger.copy(alpha = 0.2f)
                            else if (user.subscriptionPlan == "premium") AdminGold.copy(alpha = 0.2f)
                            else AdminCyan.copy(alpha = 0.2f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (user.isBanned) Icons.Default.Block
                        else if (user.subscriptionPlan == "premium") Icons.Default.Star
                        else Icons.Default.Person,
                        contentDescription = null,
                        tint = if (user.isBanned) AdminDanger
                        else if (user.subscriptionPlan == "premium") AdminGold
                        else AdminCyan,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (user.displayName.isNotBlank()) user.displayName else if (user.isGuest) "Guest Account" else "Nexus Member",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = AdminTextPrimary
                        )
                        if (user.role == "admin") {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(shape = RoundedCornerShape(4.dp), color = AdminGold.copy(alpha = 0.2f)) {
                                Text("ADMIN", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AdminGold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                            }
                        }
                    }
                    Text(
                        text = if (user.email.isNotBlank()) user.email else "UID: ${user.uid.take(12)}...",
                        fontSize = 12.sp,
                        color = AdminTextSecondary
                    )
                }
            }

            // Plan / Banned Status Pill
            Column(horizontalAlignment = Alignment.End) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (user.isBanned) AdminDanger.copy(alpha = 0.2f)
                    else if (user.subscriptionPlan == "premium") AdminGold.copy(alpha = 0.2f)
                    else Color(0xFF1E293B)
                ) {
                    Text(
                        text = if (user.isBanned) "BANNED" else if (user.subscriptionPlan == "premium") "VIP" else "FREE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (user.isBanned) AdminDanger else if (user.subscriptionPlan == "premium") AdminGold else AdminTextSecondary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun UserDetailModal(
    user: AdminUser,
    onDismiss: () -> Unit,
    onUpdate: (plan: String, durationDays: Int, isBanned: Boolean, resetTrial: Boolean) -> Unit
) {
    var selectedPlan by remember { mutableStateOf(user.subscriptionPlan) }
    var isBannedState by remember { mutableStateOf(user.isBanned) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AdminCardElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, AdminBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "User Profile & Security Controls",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = AdminTextPrimary
                )
                Spacer(modifier = Modifier.height(14.dp))

                DetailRow("UID", user.uid)
                DetailRow("Email", user.email.ifBlank { "Unregistered Guest" })
                DetailRow("Type", if (user.isGuest) "Anonymous Guest" else "Registered Member")
                DetailRow("Current Plan", user.subscriptionPlan.uppercase())
                user.subscriptionExpiresAt?.let {
                    val date = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(it.toDate())
                    DetailRow("Expires At", date)
                }
                DetailRow("Trial Claimed", if (user.isTrialUsed) "YES (Used)" else "NO (Available)")

                Spacer(modifier = Modifier.height(16.dp))

                // Actions: Upgrade VIP / Demote Free
                Text("Subscription Tier", fontSize = 12.sp, color = AdminTextSecondary, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { selectedPlan = "premium" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedPlan == "premium") AdminGold else AdminCard,
                            contentColor = if (selectedPlan == "premium") Color.Black else AdminTextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Grant VIP (30d)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { selectedPlan = "free" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedPlan == "free") AdminCyan else AdminCard,
                            contentColor = if (selectedPlan == "free") Color.Black else AdminTextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Set Free", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Ban / Unban Toggle
                Button(
                    onClick = { isBannedState = !isBannedState },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isBannedState) AdminSuccess else AdminDanger,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (isBannedState) "Unban Account" else "Ban Account (Immediate Lock)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Reset Trial Button
                Button(
                    onClick = { onUpdate(selectedPlan, 30, isBannedState, true) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = AdminCyan),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Reset 24h Trial Allowance", fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = AdminTextSecondary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = { onUpdate(selectedPlan, 30, isBannedState, false) },
                        colors = ButtonDefaults.buttonColors(containerColor = AdminGold, contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save Changes", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = AdminTextSecondary)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AdminTextPrimary)
    }
}
