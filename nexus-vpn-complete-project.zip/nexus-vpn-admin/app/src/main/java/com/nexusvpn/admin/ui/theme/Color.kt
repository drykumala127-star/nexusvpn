package com.nexusvpn.admin.ui.theme

import androidx.compose.ui.graphics.Color

val AdminBg = Color(0xFF070F22)
val AdminSurface = Color(0xFF0B1B3D)
val AdminCard = Color(0xFF102046)
val AdminCardElevated = Color(0xFF162A5A)
val AdminBorder = Color(0xFF213C78)

val AdminGold = Color(0xFFF59E0B)
val AdminCyan = Color(0xFF00D2FF)
val AdminRoyalBlue = Color(0xFF2563EB)

val AdminSuccess = Color(0xFF10B981)
val AdminDanger = Color(0xFFEF4444)
val AdminWarning = Color(0xFFF59E0B)

val AdminTextPrimary = Color(0xFFF8FAFC)
val AdminTextSecondary = Color(0xFF94A3B8)
val AdminTextTertiary = Color(0xFF64748B)
